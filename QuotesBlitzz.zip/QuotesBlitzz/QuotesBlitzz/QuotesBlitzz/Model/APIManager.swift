//
//  APIManager.swift
//  QuotesBlitzz
//
//  Created by Nirmal on 16/09/24.
//

import Foundation


class APIManager {
    
    static let shared = APIManager()
    
    private init() {}
    
    let apiKey = "U6pAJQ4EhuEd6nAL1HWfhWUb79jKjWx3Aueiw0sB"
    func fetchQuotes(category:String,completion: @escaping (Result<[Quote], Error>) -> Void) {
        let urlString = "https://api.api-ninjas.com/v1/quotes?category=\(category)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.setValue(apiKey, forHTTPHeaderField: "X-Api-Key")
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                let error = NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "No data received"])
                completion(.failure(error))
                return
            }
            
            do {
                let quotes = try JSONDecoder().decode([Quote].self, from: data)
                completion(.success(quotes))
            } catch {
                completion(.failure(error))
            }
        }
        task.resume()
    }
}


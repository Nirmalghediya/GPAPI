//
//  APIModel.swift
//  QuotesBlitzz
//
//  Created by Nirmal on 16/09/24.
//


import Foundation

struct Quote: Codable {
    let quote: String
    let author: String
}


struct Category {
    var category = ["age","alone","amazing","anger","architecture","art","attitude","beauty","best","birthday","business","car","change","communication","computers","cool","courage","dad","dating","death","design","dreams","education","environmental","equality","experience","failure","faith","family","famous","fear","fitness","food","forgiveness","freedom","friendship","funny","future","god","good","graduation","great","happiness","health","history","home","inspirational","imagination","life","love","marriage","morning","money","jealousy","success"]
}


struct QuotesModel: Codable {
    var quote: String
    var author: String
}

let SCORE: String = "quotes"

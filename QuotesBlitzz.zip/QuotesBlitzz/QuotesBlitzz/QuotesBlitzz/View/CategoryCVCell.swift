//
//  CategoryCVCell.swift
//  QuotesBlitzz
//
//  Created by Nirmal on 16/09/24.
//

import UIKit

class CategoryCVCell: UICollectionViewCell {

    @IBOutlet weak var BG_View: UIView!
    @IBOutlet weak var lbl_Categoty: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    

}

//
//  QuotesTVCell.swift
//  QuotesBlitzz
//
//  Created by Nirmal on 16/09/24.
//

import UIKit

class QuotesTVCell: UITableViewCell {

    @IBOutlet weak var BG_View: UIView!
    @IBOutlet weak var lbl_Quotes: UILabel!
    @IBOutlet weak var lbl_author: UILabel!
    @IBOutlet weak var btn_share: UIButton!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        btn_share.addTarget(self, action: #selector(Share), for: .touchUpInside)
    }

    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    @objc func Share() {
        guard let text = lbl_Quotes.text else {
                return
            }
            
            let activityViewController = UIActivityViewController(activityItems: [text], applicationActivities: nil)
            UIApplication.shared.windows.first?.rootViewController?.present(activityViewController, animated: true, completion: nil)
        }
    
}

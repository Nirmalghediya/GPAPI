//
//  FavoriteVC.swift
//  QuotesBlitzz
//
//  Created by Nirmal on 16/09/24.
//

import UIKit

class FavoriteVC: UIViewController {

    @IBOutlet weak var TableViews: UITableView!
    
    var nameList: [QuotesModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
      //QuotesTVCell
        TableViews.delegate = self
        TableViews.dataSource = self
        TableViews.register(UINib(nibName: "QuotesTVCell", bundle: nil), forCellReuseIdentifier: "QuotesTVCell")
        
        getData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getData()
    }
    private func getData()
    {
        if UserDefaults.standard.object(forKey: SCORE) != nil
        {
            let decoded  = UserDefaults.standard.data(forKey: SCORE)
            do {
                let list = try JSONDecoder().decode([QuotesModel].self, from: decoded!)
                nameList = list
                nameList.reverse()
            } catch let error {
                let alert = UIAlertController(title: "Error getting data", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                print("Error \(error.localizedDescription)")
            }
        }
        
        TableViews.reloadData()
    }


}

extension FavoriteVC:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if nameList.count == 0
        {
            let emptyLabel = UILabel(frame: CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height))
            emptyLabel.text = "No Data"
            emptyLabel.font = UIFont.systemFont(ofSize: 20, weight: .medium)
            emptyLabel.textAlignment = NSTextAlignment.center
            tableView.backgroundView = emptyLabel
        }
        else
        {
            tableView.backgroundView = nil
        }
        return nameList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableViews.dequeueReusableCell(withIdentifier: "QuotesTVCell", for: indexPath) as! QuotesTVCell
        cell.selectionStyle = .none
        cell.BG_View.ViewRedius(view: cell.BG_View, redius: 15)
        cell.lbl_Quotes.text = "\(nameList[indexPath.row].quote)"
        cell.lbl_author.text = "\(nameList[indexPath.row].author)"
        return cell
    }
    
    
}

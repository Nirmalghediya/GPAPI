//
//  SearchVC.swift
//  QuotesBlitzz
//
//  Created by Nirmal on 16/09/24.
//

import UIKit

class SearchVC: UIViewController {

    @IBOutlet weak var Search_View: UIView!
    @IBOutlet weak var Quotes_View: UIView!
    @IBOutlet weak var txt_Search: UITextField!
    @IBOutlet weak var lbl_Quotes: UILabel!
    @IBOutlet weak var lbl_Author: UILabel!
    @IBOutlet weak var btn_like: UIButton!
    @IBOutlet weak var CollectionViews: UICollectionView!
    
    @IBOutlet weak var btn_refresh: UIButton!
    
    let catgory = Category().category
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        Search_View.ViewRedius(view: Search_View, redius: 10)
        Quotes_View.ViewRedius(view: Quotes_View, redius: 10)
        txt_Search.attributedPlaceholder = NSAttributedString(
            string: "Happiness",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
           
        )
        btn_refresh.isHidden = true
        APIManager.shared.fetchQuotes(category: "beauty") { result in
                    switch result {
                    case .success(let quotes):
                        // Assuming you want to show the first quote
                        DispatchQueue.main.async {
                            if let firstQuote = quotes.first {
                                self.updateUI(with: firstQuote)
                            }
                        }
                    case .failure(let error):
                        print("Failed to fetch quotes: \(error.localizedDescription)")
                    }
                }

        //CategoryCVCell
        CollectionViews.delegate = self
        CollectionViews.dataSource = self
        CollectionViews.register(UINib(nibName: "CategoryCVCell", bundle: nil), forCellWithReuseIdentifier: "CategoryCVCell")
        
        
    }
    
    @IBAction func btn_Go(_ sender: Any) {
        APIManager.shared.fetchQuotes(category: txt_Search.text!) { result in
                    switch result {
                    case .success(let quotes):
                        // Assuming you want to show the first quote
                        DispatchQueue.main.async {
                            if let firstQuote = quotes.first {
                                self.updateUI(with: firstQuote)
                               
                            }
                        }
                    case .failure(let error):
                        print("Failed to fetch quotes: \(error.localizedDescription)")
                    }
                }
      btn_refresh.isHidden = false
    }
    
    @IBAction func btn_refresh(_ sender: Any) {
        APIManager.shared.fetchQuotes(category: txt_Search.text!) { result in
                    switch result {
                    case .success(let quotes):
                        // Assuming you want to show the first quote
                        DispatchQueue.main.async {
                            if let firstQuote = quotes.first {
                                self.updateUI(with: firstQuote)
                            }
                        }
                    case .failure(let error):
                        print("Failed to fetch quotes: \(error.localizedDescription)")
                    }
                }
    }
    
    @IBAction func btn_like(_ sender: Any) {
        SaveName(quotes: lbl_Quotes.text!, author: lbl_Author.text!)
    }
    
    @IBAction func btn_share(_ sender: Any) {
        guard let text = lbl_Quotes.text else {
                return
            }
            
            let activityViewController = UIActivityViewController(activityItems: [text], applicationActivities: nil)
            UIApplication.shared.windows.first?.rootViewController?.present(activityViewController, animated: true, completion: nil)
    }
    
    func updateUI(with quote: Quote) {
            lbl_Quotes.text = "\"\(quote.quote)\""
            lbl_Author.text = "- \(quote.author)"
        }
    
}

extension SearchVC:UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return catgory.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = CollectionViews.dequeueReusableCell(withReuseIdentifier: "CategoryCVCell", for: indexPath) as! CategoryCVCell
        cell.BG_View.ViewRedius(view: cell.BG_View, redius: 20)
        cell.lbl_Categoty.text = catgory[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedindex = catgory[indexPath.row]
        txt_Search.text = selectedindex
        APIManager.shared.fetchQuotes(category: selectedindex) { result in
                    switch result {
                    case .success(let quotes):
                        // Assuming you want to show the first quote
                        DispatchQueue.main.async {
                            if let firstQuote = quotes.first {
                                self.updateUI(with: firstQuote)
                            }
                        }
                    case .failure(let error):
                        print("Failed to fetch quotes: \(error.localizedDescription)")
                    }
                }
        btn_refresh.isHidden = false
    }
    
    func SaveName(quotes:String,author:String){
        var scoreHistory = [QuotesModel]()
        
        if UserDefaults.standard.object(forKey: SCORE) != nil {
            let decoded  = UserDefaults.standard.data(forKey: SCORE)
            do {
                scoreHistory = try JSONDecoder().decode([QuotesModel].self, from: decoded!)
            } catch let error {
                let alert = UIAlertController(title: "Error getting data", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
                print("Error \(error.localizedDescription)")
            }
        }
        
        if #available(iOS 15, *) {
            scoreHistory.append(QuotesModel(quote: quotes, author: author))
        } else {
            // Fallback on earlier versions
            scoreHistory.append(QuotesModel(quote: quotes, author: author))
        }
        
        do {
            let encodeData = try JSONEncoder().encode(scoreHistory)
            UserDefaults.standard.set(encodeData, forKey: SCORE)
            print("Data saved!")
        } catch let error {
            print("Error \(error.localizedDescription)")
        }
    }

    
    
}

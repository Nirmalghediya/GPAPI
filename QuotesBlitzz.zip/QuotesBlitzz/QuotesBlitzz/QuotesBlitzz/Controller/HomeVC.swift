//
//  HomeVC.swift
//  QuotesBlitzz
//
//  Created by Nirmal on 16/09/24.
//

import UIKit

class HomeVC: UIViewController {

    @IBOutlet weak var Heading_View: UIView!
    @IBOutlet weak var Ouote_View: UIView!
    @IBOutlet weak var lbl_Quotes: UILabel!
    @IBOutlet weak var lbl_author: UILabel!
    @IBOutlet weak var btn_like: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        APIManager.shared.fetchQuotes(category: "happiness") { result in
                    switch result {
                    case .success(let quotes):
                       
                        DispatchQueue.main.async {
                            if let firstQuote = quotes.first {
                                self.updateUI(with: firstQuote)
                            }
                        }
                    case .failure(let error):
                        print("Failed to fetch quotes: \(error.localizedDescription)")
                    }
                }
        
        Heading_View.ViewRedius(view: Heading_View, redius: 10)
        Ouote_View.ViewRedius(view: Ouote_View, redius: 10)
    }
    
    @IBAction func btn_refresh(_ sender: Any) {
        APIManager.shared.fetchQuotes(category: "happiness") { result in
                    switch result {
                    case .success(let quotes):
                        // Assuming you want to show the first quote
                        DispatchQueue.main.async {
                            if let firstQuote = quotes.first {
                                self.updateUI(with: firstQuote)
                            }
                        }
                    case .failure(let error):
                        print("Failed to fetch quotes: \(error.localizedDescription)")
                    }
                }
    }
    
    @IBAction func btn_like(_ sender: Any) {
        SaveName(quotes: lbl_Quotes.text!, author: lbl_author.text!)
    }
    
    @IBAction func btn_share(_ sender: Any) {
        guard let text = lbl_Quotes.text else {
                return
            }
            
            let activityViewController = UIActivityViewController(activityItems: [text], applicationActivities: nil)
            UIApplication.shared.windows.first?.rootViewController?.present(activityViewController, animated: true, completion: nil)
    }
    
    
    func updateUI(with quote: Quote) {
            lbl_Quotes.text = "\"\(quote.quote)\""
            lbl_author.text = "- \(quote.author)"
        }
    
    func SaveName(quotes:String,author:String){
        var scoreHistory = [QuotesModel]()
        
        if UserDefaults.standard.object(forKey: SCORE) != nil {
            let decoded  = UserDefaults.standard.data(forKey: SCORE)
            do {
                scoreHistory = try JSONDecoder().decode([QuotesModel].self, from: decoded!)
            } catch let error {
                let alert = UIAlertController(title: "Error getting data", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
                print("Error \(error.localizedDescription)")
            }
        }
        
        if #available(iOS 15, *) {
            scoreHistory.append(QuotesModel(quote: quotes, author: author))
        } else {
            // Fallback on earlier versions
            scoreHistory.append(QuotesModel(quote: quotes, author: author))
        }
        
        do {
            let encodeData = try JSONEncoder().encode(scoreHistory)
            UserDefaults.standard.set(encodeData, forKey: SCORE)
            print("Data saved!")
        } catch let error {
            print("Error \(error.localizedDescription)")
        }
    }


}



extension UIView {
    func ViewRedius(view:UIView,redius:CGFloat){
        view.layer.cornerRadius = redius
    }
}

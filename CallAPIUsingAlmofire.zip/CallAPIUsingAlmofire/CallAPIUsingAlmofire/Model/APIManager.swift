//
//  APIManager.swift
//  CallAPIUsingAlmofire
//
//  Created by Nirmal on 11/08/24.
//

import Foundation
import Alamofire

struct PostResponse: Codable {
    let id: Int
    let title: String
    let body: String
    let userId: Int
}


class APIManager {

    static let shared = APIManager()
    private let baseURL = "https://api.pexels.com/v1/search"
    private let apiKey = "JxEtlKnkHpcVwyLsgGSfzYUJ8SEWLXbALB8nX49vFonfArXSkZ1XAyGX"

    private init() {}

    func GetAPI(query: String, completion: @escaping (Result<[String: Any], AFError>) -> Void) {
        let url = "\(baseURL)?query=\(query)&per_page=80"
        let headers: HTTPHeaders = [
            "Authorization": apiKey
        ]

        AF.request(url, headers: headers).validate().responseJSON { response in
            switch response.result {
            case .success(let value):
                if let json = value as? [String: Any] {
                    completion(.success(json))
                } else {
                    completion(.failure(AFError.responseValidationFailed(reason: .dataFileNil)))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    func createPost(title: String, body: String, userId: Int, completion: @escaping (Result<PostResponse, AFError>) -> Void) {
            
            let url = "https://jsonplaceholder.typicode.com/posts"
            let parameters: [String: Any] = [
                "title": title,
                "body": body,
                "userId": userId
            ]
            
            AF.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default)
                .validate()
                .responseDecodable(of: PostResponse.self) { response in
                    completion(response.result)
                }
        }
    
    
}


extension Dictionary
{
    func percentEscaped() -> String
    {
        return map { (key, Value) in
            let escapedkey = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            let escapedValue = "\(Value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            return escapedkey + "=" + escapedValue
        }
        .joined(separator: "&")
    }
}

extension CharacterSet
{
    static let urlQueryValueAllowed: CharacterSet = {
       let generalDelimitersToEncode = ":#[]@"
        let subDelimilersToEncode = "!$&'()*+,;="
        
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "\(generalDelimitersToEncode)\(subDelimilersToEncode)")
        return allowed
    }()
}

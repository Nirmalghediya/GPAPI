//
//  DataModel.swift
//  CallAPIUsingAlmofire
//
//  Created by Nirmal on 11/08/24.
//

import Foundation

struct PexelsResponse: Codable {
    let photos: [Photo]
}

struct Photo: Codable {
    let id: Int
    let url: String
    let src: Src
}

struct Src: Codable {
    let medium: String
}

//
//  HomeVC.swift
//  CallAPIUsingAlmofire
//
//  Created by Nirmal on 11/08/24.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
      
        APIManager.shared.createPost(title: "foo", body: "bar", userId: 1) { result in
                   switch result {
                   case .success(let postResponse):
                       print("Post created: \(postResponse)")
                   case .failure(let error):
                       print("Error creating post: \(error)")
                   }
               }
           
      
    }
    
    @IBAction func btn_get(_ sender: Any) {
        
    }
    
    @IBAction func btn_post(_ sender: Any) {
    }
    
   
}

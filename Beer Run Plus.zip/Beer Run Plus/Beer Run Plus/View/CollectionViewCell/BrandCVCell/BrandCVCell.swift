//
//  BrandCVCell.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 06/02/25.
//

import UIKit

class BrandCVCell: UICollectionViewCell {

    @IBOutlet weak var BorderView: BorderGradientView!
    
    @IBOutlet weak var BGView: UIView! {
        didSet {
            BGView.layer.cornerRadius = 16
        }
    }
    @IBOutlet weak var imgBrand: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

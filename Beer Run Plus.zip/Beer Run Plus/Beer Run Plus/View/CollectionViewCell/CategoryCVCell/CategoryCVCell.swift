//
//  CategoryCVCell.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 06/02/25.
//

import UIKit

class CategoryCVCell: UICollectionViewCell {

    @IBOutlet weak var imgImage: UIImageView!
    @IBOutlet weak var lblCategory: UILabel!
    @IBOutlet weak var BGView: GradientView! {
        didSet {
            BGView.applyShadow()
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

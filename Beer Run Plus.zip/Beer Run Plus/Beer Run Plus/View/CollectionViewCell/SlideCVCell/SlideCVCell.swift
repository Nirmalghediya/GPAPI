//
//  SlideCVCell.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 03/02/25.
//

import UIKit

class SlideCVCell: UICollectionViewCell {

    @IBOutlet weak var BGView: UIView! {
        didSet {
            BGView.layer.cornerRadius = 20
        }
    }
    
    @IBOutlet weak var imgImage: UIImageView!{
        didSet {
            imgImage.layer.cornerRadius = 20
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

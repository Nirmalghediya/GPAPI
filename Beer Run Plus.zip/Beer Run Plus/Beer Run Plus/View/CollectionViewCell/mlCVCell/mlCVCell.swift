//
//  mlCVCell.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 06/02/25.
//

import UIKit

class mlCVCell: UICollectionViewCell {

    @IBOutlet weak var BGView: UIView! {
        didSet {
            BGView.layer.cornerRadius = 15
            BGView.layer.borderColor = UIColor.white.cgColor
            BGView.layer.borderWidth = 1
        }
    }
    @IBOutlet weak var lblML: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

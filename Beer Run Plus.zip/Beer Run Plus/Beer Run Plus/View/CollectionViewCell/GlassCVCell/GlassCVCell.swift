//
//  GlassCVCell.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 03/02/25.
//

import UIKit

class GlassCVCell: UICollectionViewCell {

    @IBOutlet weak var GradientView: GradientView!
    @IBOutlet weak var imgBottle: UIImageView!
    @IBOutlet weak var lblName: UILabel! {
        didSet {
            lblName.transform = CGAffineTransform(rotationAngle: CGFloat.pi / -2)
            
        }
    }
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

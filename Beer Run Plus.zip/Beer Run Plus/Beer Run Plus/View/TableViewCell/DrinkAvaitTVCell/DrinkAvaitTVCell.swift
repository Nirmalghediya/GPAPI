//
//  DrinkAvaitTVCell.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 03/02/25.
//

import UIKit

class DrinkAvaitTVCell: UITableViewCell {

    @IBOutlet weak var BGView: UIView! {
        didSet{
            BGView.layer.cornerRadius = 20
            BGView.applyBottomShadow(to: BGView)
        }
    }
    @IBOutlet weak var imgImage: UIImageView! {
        didSet{
            imgImage.layer.cornerRadius = 20
        }
    }
    
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var blackshade: UIImageView! {
        didSet{
            blackshade.translatesAutoresizingMaskIntoConstraints = false
            blackshade.layer.cornerRadius = 20
            blackshade.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            blackshade.layer.masksToBounds = true
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

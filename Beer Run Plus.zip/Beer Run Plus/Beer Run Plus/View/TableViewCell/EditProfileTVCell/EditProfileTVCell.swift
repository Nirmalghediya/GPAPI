//
//  EditProfileTVCell.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 06/02/25.
//

import UIKit

class EditProfileTVCell: UITableViewCell {

    @IBOutlet weak var imgProfile: UIImageView!  {
        didSet {
            imgProfile.layer.cornerRadius = imgProfile.frame.height / 2
            imgProfile.clipsToBounds = true
        }
    }
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblNumber: UILabel!
    
    @IBOutlet weak var btnEdit: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

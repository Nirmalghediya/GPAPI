//
//  OrderTVCell.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 06/02/25.
//

import UIKit

class OrderTVCell: UITableViewCell {

    @IBOutlet weak var GradientView: GradientView!
    
    @IBOutlet weak var lblOrder: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblBrand: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    
    @IBOutlet weak var statusView: UIView! {
        didSet {
            statusView.layer.cornerRadius = 4
        }
    }
    @IBOutlet weak var lblStatus: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

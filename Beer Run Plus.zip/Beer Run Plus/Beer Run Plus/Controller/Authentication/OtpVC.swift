//
//  OtpVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 01/02/25.
//

import UIKit

class OtpVC: UIViewController {

    @IBOutlet weak var VOne: UIView!
    @IBOutlet weak var V2: UIView!
    @IBOutlet weak var V3: UIView!
    @IBOutlet weak var V4: UIView!
    @IBOutlet weak var V5: UIView!
    @IBOutlet weak var V6: UIView!
    
    
    @IBOutlet weak var txtOne: UITextField!
    @IBOutlet weak var txtTwo: UITextField!
    @IBOutlet weak var txtThree: UITextField!
    @IBOutlet weak var txtFour: UITextField!
    @IBOutlet weak var txtFive: UITextField!
    @IBOutlet weak var txtSix: UITextField!
    
    @IBOutlet weak var ResendView: UIView!
    
    @IBOutlet weak var btnResend: UIButton! {
        didSet {
            btnResend.setAttributedTitle(btnResend.underlinedText("Resend"), for: .normal)
            btnResend.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
        }
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        [txtOne, txtTwo, txtThree, txtFour, txtFive, txtSix].forEach {
                    $0?.delegate = self
                    $0?.addTarget(self, action: #selector(self.textdidChange(textfield:)), for: .editingChanged)
                    $0?.keyboardType = .numberPad  // Only allow numeric input
                }
                
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                view.addGestureRecognizer(tapGesture)
        
      
        
    }
    
    @objc func dismissKeyboard() {
            view.endEditing(true) // This will dismiss the keyboard
        }
    @objc func textdidChange(textfield: UITextField) {
           let text = textfield.text ?? ""
           
           if text.count > 1 {
               textfield.text = String(text.prefix(1)) // Allow only one character
           }

           if text.count == 1 {
               switch textfield {
               case txtOne: txtTwo.becomeFirstResponder()
               case txtTwo: txtThree.becomeFirstResponder()
               case txtThree: txtFour.becomeFirstResponder()
               case txtFour: txtFive.becomeFirstResponder()
               case txtFive: txtSix.becomeFirstResponder()
               case txtSix:
                   txtSix.resignFirstResponder() // Hide keyboard
                   verifyOTPAndProceed() // Navigate when all fields are filled
               default: break
               }
           }
       }
   
    @objc func buttonTapped() {
        view.showToast(message: "OTP Resend on your Mobile Number", duration: 2.0)
        }
    
    @IBAction func btnBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func verifyOTPAndProceed() {
           let otp = "\(txtOne.text ?? "")\(txtTwo.text ?? "")\(txtThree.text ?? "")\(txtFour.text ?? "")\(txtFive.text ?? "")\(txtSix.text ?? "")"

           if otp.count == 6 {
               print("Entered OTP: \(otp)")
               let nextVC = storyboard?.instantiateViewController(withIdentifier: "LocationPremissionVC") as! LocationPremissionVC
               navigationController?.pushViewController(nextVC, animated: true)
           }
       }
    

}

extension OtpVC:UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
            switch textField {
            case txtOne: VOne.applyotpborder(redius: 0)
            case txtTwo: V2.applyotpborder(redius: 0)
            case txtThree: V3.applyotpborder(redius: 0)
            case txtFour: V4.applyotpborder(redius: 0)
            case txtFive: V5.applyotpborder(redius: 0)
            case txtSix: V6.applyotpborder(redius: 0)
            default: break
            }
        }
}

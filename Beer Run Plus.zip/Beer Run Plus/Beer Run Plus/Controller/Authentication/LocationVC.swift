//
//  LocationVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 03/02/25.
//

import UIKit
import MapKit

class LocationVC: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var EnterLocationView: UIView!{
        didSet {
            EnterLocationView.applylightborder(redius: 8)
        }
    }
    @IBOutlet weak var txtLocation: UITextField!{
        didSet{
            txtLocation.applylightBorder(textfield: txtLocation,placeholder: "Search Location")
        }
    }
    
    @IBOutlet weak var btnLocation: UIButton! {
        didSet{
            btnLocation.addTarget(self, action: #selector(gotoHome), for: .touchUpInside)
        }
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    var matchingItems: [MKMapItem] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setuptable()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
    }
    
    private func setuptable(){
        //LocationTVCell
        tableView.delegate = self
        tableView.dataSource = self
        txtLocation.delegate = self
        tableView.register(UINib(nibName: "LocationTVCell", bundle: nil), forCellReuseIdentifier: "LocationTVCell")
        
        txtLocation.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)
    }

    @objc func dismissKeyboard() {
            view.endEditing(true) // This will dismiss the keyboard
        }
    
    @objc func gotoHome(){
        let storyboard = UIStoryboard(name: "Home", bundle: nil)
        if let secondVC = storyboard.instantiateViewController(withIdentifier: "MainTabBar") as? MainTabBar {
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
    }
    @objc func textFieldDidChange() {
            guard let query = txtLocation.text, !query.isEmpty else {
                matchingItems.removeAll()
                tableView.reloadData()
                return
            }
            searchLocation(query: query)
        }

        func searchLocation(query: String) {
            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = query
            request.resultTypes = .address // ✅ Ensures address-based results
            
            // 🌍 Set region to cover a broad area
            let regionSpan = MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2)
            request.region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), span: regionSpan)

            let search = MKLocalSearch(request: request)

            search.start { response, error in
                guard let response = response else {
                    print("Search error: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                
                self.matchingItems = response.mapItems // ✅ Get multiple results
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
}

extension LocationVC:UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return matchingItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LocationTVCell", for: indexPath) as! LocationTVCell
                let selectedItem = matchingItems[indexPath.row]

                // 🏠 Display Full Address
                let name = selectedItem.placemark.name ?? "Unknown Place"
                let address = [
                    selectedItem.placemark.subThoroughfare ?? "",
                    selectedItem.placemark.thoroughfare ?? "",
                    selectedItem.placemark.locality ?? "",
                    selectedItem.placemark.administrativeArea ?? "",
                    selectedItem.placemark.country ?? ""
                ].filter { !$0.isEmpty }.joined(separator: ", ")

                cell.lblLocation.text = address
               // cell.detailTextLabel?.text = address // ✅ Show full address
                cell.selectionStyle = .none

                return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let selectedItem = matchingItems[indexPath.row]
            print("Selected Location: \(selectedItem.placemark.title ?? "Unknown")")
        let storyboard = UIStoryboard(name: "Home", bundle: nil)
        if let secondVC = storyboard.instantiateViewController(withIdentifier: "MainTabBar") as? MainTabBar {
            self.navigationController?.pushViewController(secondVC, animated: true)
        }
        
        }
}

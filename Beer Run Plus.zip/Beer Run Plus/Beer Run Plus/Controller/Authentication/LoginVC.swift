//
//  LoginVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 01/02/25.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var countryView: UIView! {
        didSet {
            countryView.applylightborder(redius: 8)
        }
    }
    
    @IBOutlet weak var numberView: UIView!{
        didSet {
            numberView.applylightborder(redius: 8)
        }
    }
    
    @IBOutlet weak var txtCountry: UITextField! {
        didSet{
            txtCountry.applylightBorder(textfield: txtCountry,placeholder: "+91")
        }
    }
    
    @IBOutlet weak var txtNumber: UITextField! {
        didSet{
            txtNumber.applylightBorder(textfield: txtNumber,placeholder: "09876 54321")
        }
    }
    
    @IBOutlet weak var btnContinue: UIButton!{
        didSet {
            btnContinue.makeroundButton()
            btnContinue.addTarget(self, action: #selector(gotoOTP), for: .touchUpInside)
        }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
        txtNumber.delegate = self
    }
    
    @objc func dismissKeyboard() {
            view.endEditing(true) // This will dismiss the keyboard
        }
    
    @objc func gotoOTP(){
        let vc = storyboard?.instantiateViewController(withIdentifier: "OtpVC") as! OtpVC
        navigationController?.pushViewController(vc, animated: true)
    }
    

}

extension LoginVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder() // Hide keyboard when return is pressed
        return true
    }
}

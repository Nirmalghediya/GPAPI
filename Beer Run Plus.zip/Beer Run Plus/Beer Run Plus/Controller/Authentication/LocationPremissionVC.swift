//
//  LocationPremissionVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 03/02/25.
//

import UIKit

class LocationPremissionVC: UIViewController {

    @IBOutlet weak var btnAccessLocation: UIButton! {
        didSet {
            btnAccessLocation.makeroundButton()
        }
    }
    
    @IBOutlet weak var btnEnterLoacation: UIButton! {
        didSet {
            btnEnterLoacation.addTarget(self, action: #selector(gotoLoaction), for: .touchUpInside)
        }
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    
    @objc func gotoLoaction(){
        let vc = storyboard?.instantiateViewController(withIdentifier: "LocationVC") as! LocationVC
        navigationController?.pushViewController(vc, animated: true)
    }
   

}

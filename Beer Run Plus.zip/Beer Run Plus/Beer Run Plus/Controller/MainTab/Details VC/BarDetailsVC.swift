//
//  BarDetailsVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 06/02/25.
//

import UIKit

class BarDetailsVC: UIViewController {

    @IBOutlet weak var TopView: UIView! {
        didSet{
            TopView.layer.cornerRadius = 20
            TopView.applyBottomShadow(to: TopView)
        }
    }
    @IBOutlet weak var imgBar: UIImageView!{
        didSet{
            imgBar.layer.cornerRadius = 20
        }
    }
    
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    
    @IBOutlet weak var categoryCollectionView: UICollectionView!
    
    @IBOutlet weak var brandCollectionView: UICollectionView!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var imgBlackshade: UIImageView! {
        didSet{
            imgBlackshade.translatesAutoresizingMaskIntoConstraints = false
            imgBlackshade.layer.cornerRadius = 20
            imgBlackshade.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
            imgBlackshade.layer.masksToBounds = true
        }
    }
    var category = ["Beer","Cognac","Extra","Gin","Rum","Tequila","Vodka","Whiskey","Wine"]
    var brand = ["4","5","6","7","8"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionView()
        tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = true
    }
    
    private func setupCollectionView(){
        categoryCollectionView.delegate = self
        categoryCollectionView.dataSource = self
        categoryCollectionView.register(UINib(nibName: "CategoryCVCell", bundle: nil), forCellWithReuseIdentifier: "CategoryCVCell")
        
        brandCollectionView.delegate = self
        brandCollectionView.dataSource = self
        brandCollectionView.register(UINib(nibName: "BrandCVCell", bundle: nil), forCellWithReuseIdentifier: "BrandCVCell")
    }

    @IBAction func btnBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCart(_ sender: Any) {
    }
    

}

extension BarDetailsVC:UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == categoryCollectionView {
            return category.count
        } else {
            return brand.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == categoryCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCVCell", for: indexPath) as! CategoryCVCell
            cell.imgImage.image = UIImage(named: category[indexPath.row])
            cell.lblCategory.text = category[indexPath.row]
            return cell
        }
        else {
            let  cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BrandCVCell", for: indexPath) as! BrandCVCell
            cell.imgBrand.image = UIImage(named: brand[indexPath.row])
            return cell
        }
    }
    
    
}


//extension BarDetailsVC:UITableViewDelegate , UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        <#code#>
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        <#code#>
//    }
//    
//    
//}

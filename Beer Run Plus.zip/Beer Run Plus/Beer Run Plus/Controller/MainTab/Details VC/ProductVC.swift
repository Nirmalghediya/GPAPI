//
//  ProductVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 04/02/25.
//

import UIKit

class ProductVC: UIViewController {

    @IBOutlet weak var btnPrice: UIButton!{
        didSet{
            btnPrice.makeroundButton()
        }
    }
    @IBOutlet weak var mlCollectionView: UICollectionView!
    
    @IBOutlet weak var imgBottle: UIImageView!
    
    @IBOutlet weak var btnAddtoCart: UIButton! {
        didSet{
            btnAddtoCart.makeroundButton()
        }
    }
    
    @IBOutlet weak var stapper: CustomStepper!
    
    @IBOutlet weak var mainBG: MainGradientView!
    
    var mlData = ["300ml","720ml","1L"]
    var selectedIndex = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBarController?.tabBar.isHidden = true
        navigationController?.navigationBar.isHidden = true
        setupMLcollectionview()
        DispatchQueue.main.async {
                    self.mlCollectionView.reloadData()
                }
    }
    
    private func setupMLcollectionview(){
        mlCollectionView.delegate = self
        mlCollectionView.dataSource = self
        mlCollectionView.register(UINib(nibName: "mlCVCell", bundle: nil), forCellWithReuseIdentifier: "mlCVCell")
    }
    
    @IBAction func btnBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCart(_ sender: Any) {
    }
    

}

extension ProductVC:UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return mlData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "mlCVCell", for: indexPath) as! mlCVCell
        if indexPath.item == selectedIndex {
            cell.BGView.backgroundColor = .white
                    cell.lblML.textColor = .black
                } else {
                    cell.BGView.backgroundColor = .clear
                    cell.lblML.textColor = .white
                }
                
                cell.lblML.text = mlData[indexPath.item]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            selectedIndex = indexPath.item
            mlCollectionView.reloadData() // Refresh the UI
        }
    
}

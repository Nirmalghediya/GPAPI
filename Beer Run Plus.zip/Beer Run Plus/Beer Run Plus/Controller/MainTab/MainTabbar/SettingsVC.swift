//
//  SettingsVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 03/02/25.
//

import UIKit

class SettingsVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnLogout: UIButton!{
        didSet{
            btnLogout.makeroundButton()
        }
    }
    
    var titlearr = ["Addresses","Payment & Cards","Past Orders","Customer Supports","Privacy Policy","Terms & Condition", "Delete Account"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        tableviewsetup()
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = false
    }
    
    private func tableviewsetup(){
        tableView.delegate  = self
        tableView.dataSource = self
        
        tableView.register(UINib(nibName: "EditProfileTVCell", bundle: nil), forCellReuseIdentifier: "EditProfileTVCell")
        tableView.register(UINib(nibName: "SettingTVCell", bundle: nil), forCellReuseIdentifier: "SettingTVCell")
    }
    

}

extension SettingsVC:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titlearr.count + 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "EditProfileTVCell", for: indexPath) as! EditProfileTVCell
          //  cell.btn_Edit.addTarget(self, action: #selector(editProfile), for: .touchUpInside)
            cell.selectionStyle = .none
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "SettingTVCell", for: indexPath) as! SettingTVCell
            let titleIndex = indexPath.row - 1 // Adjust index to match titlearr
                    if titleIndex < titlearr.count {   // Ensure safe index access
                        cell.lblTitle.text = titlearr[titleIndex]
                    }
            if indexPath.row == 1 {
                cell.lblSubtitle.text = "Edit, Delete & Add new Address"
            } else if indexPath.row == 2 {
                cell.lblSubtitle.text = "Add & Delete your credit or debit card"
            } else {
                cell.lblSubtitle.isHidden = true
            }
            cell.selectionStyle = .none
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 90
        } else if indexPath.row == 1 {
            return 58
        } else if indexPath.row == 2 {
            return 58
        }
        else {
            return 40
        }
    }
    
}

//
//  MyOrderVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 03/02/25.
//

import UIKit

class MyOrderVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var orderData = ["Order #25986385","Order #45832988","Order #17382543"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        setupTableview()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = false
    }
    
    private func setupTableview(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "OrderTVCell", bundle: nil), forCellReuseIdentifier: "OrderTVCell")
    }

    

}

extension MyOrderVC:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return orderData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderTVCell", for: indexPath) as! OrderTVCell
        cell.lblOrder.text = orderData[indexPath.row]
        if indexPath.row == 0
        {
            cell.statusView.backgroundColor = UIColor(hex: "#AFDDFF")
            cell.lblStatus.text = "On the Way"
        } else  if indexPath.row == 1
        {
            cell.statusView.backgroundColor = UIColor(hex: "#C6FFDE")
            cell.lblStatus.text = "Ready for Pick"
        } else  if indexPath.row == 2
        {
            cell.statusView.backgroundColor = UIColor(hex: "#FFE09D")
            cell.lblStatus.text = "Pending"
        }
        cell.selectionStyle = .none
        return cell
    }
    
    
}

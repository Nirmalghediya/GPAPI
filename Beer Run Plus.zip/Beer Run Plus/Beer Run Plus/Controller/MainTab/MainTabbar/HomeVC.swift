//
//  HomeVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 03/02/25.
//

import UIKit

class HomeVC: UIViewController {

    @IBOutlet weak var btnCart: UIButton!
    
    @IBOutlet weak var SlidecollectionView: UICollectionView!
    
    @IBOutlet weak var GlassCollectionView: UICollectionView!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var tableViewHeightConstraint: NSLayoutConstraint!
    
    
    var order = ["Mofattiyu Street","Desi Potli Street","50 Ni 3"]
    var darubottele = ["1","2","2"]
    var darutype = ["Beer","Wine","Whiskey"]
    var slide = ["b1","b2","b3"]
    //MARK: viewdidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        tableViewseyup()
        collectionViewsetup()
        updateTableViewHeight()
    }
    
    //MARK: register Tableview
    
    private func tableViewseyup(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "DrinkAvaitTVCell", bundle: nil), forCellReuseIdentifier: "DrinkAvaitTVCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = false
    }
    //MARK: register Collectionview
    
    private func collectionViewsetup(){
        SlidecollectionView.delegate = self
        SlidecollectionView.dataSource = self
        SlidecollectionView.register(UINib(nibName: "SlideCVCell", bundle: nil), forCellWithReuseIdentifier: "SlideCVCell")
        
        GlassCollectionView.delegate = self
        GlassCollectionView.dataSource = self
        GlassCollectionView.register(UINib(nibName: "GlassCVCell", bundle: nil), forCellWithReuseIdentifier: "GlassCVCell")
    }
    
    private func updateTableViewHeight() {
        let rowCount = order.count
        let singleRowHeight: CGFloat = 220  // Adjust height per row
        let minHeight: CGFloat = 220        // Minimum height if there are no rows

        // Calculate the new height
        let newHeight = max(minHeight, CGFloat(rowCount) * singleRowHeight)

        // Update the constraint
        tableViewHeightConstraint.constant = newHeight

        // Animate the height change
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    

}

//MARK: Tableview

extension HomeVC:UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        updateTableViewHeight()
        return order.count
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DrinkAvaitTVCell", for: indexPath) as! DrinkAvaitTVCell
        cell.selectionStyle = .none
        cell.lblName.text = order[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "BarDetailsVC") as! BarDetailsVC
        navigationController?.pushViewController(vc, animated: true)
    }
}


extension HomeVC:UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == SlidecollectionView {
            return 20/*slide.count*/
        }
        else {
            return 10/*darutype.count*/
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == SlidecollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SlideCVCell", for: indexPath) as! SlideCVCell
            //cell.imgImage.image = UIImage(named: slide[indexPath.row])
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GlassCVCell", for: indexPath) as! GlassCVCell
//            cell.imgBottle.image = UIImage(named: darubottele[indexPath.row])
//            cell.lblName.text = darutype[indexPath.row]
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == GlassCollectionView {
            let vc = storyboard?.instantiateViewController(withIdentifier: "ProductVC") as! ProductVC
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}

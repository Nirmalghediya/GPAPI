//
//  SplaceVC.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 01/02/25.
//

import UIKit

class SplaceVC: UIViewController {

    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
       
    }
    

   

}

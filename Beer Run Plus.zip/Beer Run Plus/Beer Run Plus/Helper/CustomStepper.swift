//
//  CustomStepper.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 04/02/25.
//

import UIKit

protocol CustomStepperDelegate: AnyObject {
    func stepperValueChanged(value: Int)
}

class CustomStepper: UIView {
    
    private let decrementButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("−", for: .normal)
        button.titleLabel?.textColor = .white
        button.titleLabel?.font = .boldSystemFont(ofSize: 22)
        return button
    }()
    
    private let incrementButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("+", for: .normal)
        button.titleLabel?.textColor = .white
        button.titleLabel?.font = .boldSystemFont(ofSize: 22)
        return button
    }()
    
    private let valueLabel: UILabel = {
        let label = UILabel()
        label.text = "0"
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 18)
        label.textColor = .white
        return label
    }()
    
    weak var delegate: CustomStepperDelegate?
    
    var value: Int = 0 {
        didSet {
            valueLabel.text = "\(value)"
            delegate?.stepperValueChanged(value: value)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    private func setupView() {
        
        layer.cornerRadius = layer.frame.height / 2
        layer.borderWidth = 1
        layer.borderColor = UIColor.white.cgColor
        backgroundColor = .clear
        
        
        // Add subviews
        
        addSubview(decrementButton)
        addSubview(valueLabel)
        addSubview(incrementButton)
        
        // Set up layout
        decrementButton.translatesAutoresizingMaskIntoConstraints = false
        valueLabel.translatesAutoresizingMaskIntoConstraints = false
        incrementButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            decrementButton.leadingAnchor.constraint(equalTo: leadingAnchor),
            decrementButton.widthAnchor.constraint(equalToConstant: 40),
            decrementButton.heightAnchor.constraint(equalToConstant: 40),
            decrementButton.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            valueLabel.leadingAnchor.constraint(equalTo: decrementButton.trailingAnchor, constant: 8),
            valueLabel.trailingAnchor.constraint(equalTo: incrementButton.leadingAnchor, constant: -8),
            valueLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            valueLabel.widthAnchor.constraint(equalToConstant: 50),
            
            incrementButton.trailingAnchor.constraint(equalTo: trailingAnchor),
            incrementButton.widthAnchor.constraint(equalToConstant: 40),
            incrementButton.heightAnchor.constraint(equalToConstant: 40),
            incrementButton.centerYAnchor.constraint(equalTo: centerYAnchor),
        ])
        
        // Add actions
        decrementButton.addTarget(self, action: #selector(decrementValue), for: .touchUpInside)
        incrementButton.addTarget(self, action: #selector(incrementValue), for: .touchUpInside)
        
        // Styling
//        decrementButton.layer.cornerRadius = 8
//        incrementButton.layer.cornerRadius = 8
//        decrementButton.backgroundColor = .systemGray5
//        incrementButton.backgroundColor = .systemGray5
    }
    
    @objc private func decrementValue() {
        if value > 0 { // Prevent negative values
            value -= 1
        }
    }
    
    @objc private func incrementValue() {
        value += 1
    }
}

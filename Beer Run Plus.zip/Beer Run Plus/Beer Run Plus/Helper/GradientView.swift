//
//  GradientView.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 01/02/25.
//

import Foundation
import UIKit

class GradientView: UIView {
    
    private let gradientLayer = CAGradientLayer()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupGradients()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupGradients()
    }
    
    private func setupGradients() {
        gradientLayer.colors = [
            UIColor(hex: "#282828").cgColor,
            UIColor(hex: "#101010").cgColor
        ]
        
        // Set gradient to be vertical (top to bottom)
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0) // Center-top
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0) // Center-bottom
        
        gradientLayer.frame = bounds
        gradientLayer.cornerRadius = 20
        layer.insertSublayer(gradientLayer, at: 0)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = bounds
    }
}

/*
 mainBG.layer.cornerRadius = 20
 mainBG.layer.maskedCorners = [.layerMinXMaxYCorner]
 mainBG.layer.masksToBounds = true
 */

class MainGradientView: UIView {
    
    private let gradientLayer = CAGradientLayer()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupGradients()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupGradients()
    }
    
    private func setupGradients() {
        gradientLayer.colors = [
            UIColor(hex: "#575757").cgColor,
            UIColor(hex: "#232323").cgColor
        ]
        
        
        // Set gradient to be vertical (top to bottom)
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0) // Center-top
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0) // Center-bottom
        
        gradientLayer.frame = bounds
        gradientLayer.cornerRadius = 70
        gradientLayer.maskedCorners = [.layerMinXMaxYCorner]
        layer.insertSublayer(gradientLayer, at: 0)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = bounds
    }
}

class BorderGradientView: UIView {
    
    private let gradientLayer = CAGradientLayer()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupGradients()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupGradients()
    }
    
    private func setupGradients() {
        gradientLayer.colors = [
            UIColor(hex: "#000000").cgColor,
            UIColor(hex: "#FFFFFF").cgColor
        ]
        
        
        // Set gradient to be vertical (top to bottom)
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0) // Center-top
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0) // Center-bottom
        
        gradientLayer.frame = bounds
        gradientLayer.cornerRadius = 16
        layer.insertSublayer(gradientLayer, at: 0)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = bounds
    }
}

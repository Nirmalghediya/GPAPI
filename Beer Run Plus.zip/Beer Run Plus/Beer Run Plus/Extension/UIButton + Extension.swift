//
//  UIButton + Extension.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 01/02/25.
//

import Foundation
import UIKit

extension UIButton {
    func makeroundButton(){
        layer.cornerRadius = layer.frame.height / 2
    }
    
    func underlinedText(_ text: String) -> NSAttributedString {
            return NSAttributedString(string: text, attributes: [.underlineStyle: NSUnderlineStyle.single.rawValue])
    }
    
}

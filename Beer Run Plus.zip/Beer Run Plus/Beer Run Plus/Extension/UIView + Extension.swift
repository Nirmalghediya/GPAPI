//
//  UIView + Extension.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 01/02/25.
//

import Foundation
import UIKit

extension UIView {
    func applylightborder(redius: CGFloat){
        layer.borderWidth = 1.0
        layer.borderColor = UIColor(hex: "#A6CFFE").withAlphaComponent(0.5).cgColor
        backgroundColor = .clear
        layer.cornerRadius = redius
    }
    
    func applydarkborder(redius: CGFloat){
        layer.borderWidth = 1.0
        layer.borderColor = UIColor(hex: "#FFFFFF").withAlphaComponent(0.3).cgColor
        backgroundColor = .clear
        layer.cornerRadius = redius
    }
    
    func applyotpborder(redius: CGFloat){
        layer.borderWidth = 1.0
        layer.borderColor = UIColor.white.cgColor
        layer.cornerRadius = redius
    }
    
     func setupGradient() {
         let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            UIColor(hex: "#282828").cgColor,
            UIColor(hex: "#101010").cgColor
        ]
        
        // Set gradient to be vertical (top to bottom)
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0) // Center-top
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0) // Center-bottom
        
        gradientLayer.frame = bounds
       // gradientLayer.cornerRadius = 20
        layer.insertSublayer(gradientLayer, at: 0)
    }

    
    func applyDarkGrayGradient() {
        layer.cornerRadius = 20
            let gradientLayer = CAGradientLayer()
            gradientLayer.frame = self.bounds
            gradientLayer.colors = [
                UIColor(hex: "#282828").cgColor, // Dark Gray
                UIColor(hex: "#101010").cgColor  // Black
            ]
            gradientLayer.startPoint = CGPoint(x: 0.5, y: 0) // Top Center
            gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)   // Bottom Center

            self.layer.insertSublayer(gradientLayer, at: 0)
        }
    
    func showToast(message: String, duration: TimeInterval) {
          let toastLabel = UILabel()
          toastLabel.text = message
          toastLabel.textColor = .white
          toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.7)
          toastLabel.textAlignment = .center
          toastLabel.font = UIFont.systemFont(ofSize: 14)
          toastLabel.alpha = 1.0
          toastLabel.layer.cornerRadius = 10
          toastLabel.clipsToBounds = true
          
          let textSize = toastLabel.intrinsicContentSize
          let labelWidth = min(textSize.width + 40, frame.width - 40)
          let labelHeight = textSize.height + 20
          toastLabel.frame = CGRect(x: (frame.width - labelWidth) / 2,
                                    y: frame.height - 100,
                                    width: labelWidth,
                                    height: labelHeight)
          
          addSubview(toastLabel)
          
          UIView.animate(withDuration: 0.5, delay: duration, options: .curveEaseOut, animations: {
              toastLabel.alpha = 0.0
          }) { _ in
              toastLabel.removeFromSuperview()
          }
      }
    
    func applyBottomShadow(to view: UIView) {
        view.layer.shadowColor = UIColor.white.cgColor
        view.layer.shadowOpacity = 0.3  // Adjust the shadow opacity
        view.layer.shadowOffset = CGSize(width: 0, height: 4)  // Moves shadow down
        view.layer.shadowRadius = 3  // Softness of shadow
        view.layer.masksToBounds = false
    }

    func applyShadow(color: UIColor = .white, opacity: Float = 0.5, offset: CGSize = CGSize(width: 1, height: 1), radius: CGFloat = 2) {
            self.layer.shadowColor = color.cgColor
            self.layer.shadowOpacity = opacity
            self.layer.shadowOffset = offset
            self.layer.shadowRadius = radius
            self.layer.masksToBounds = false
        }
    
    func applyBottomCornerRadius(to view: UIView, radius: CGFloat) {
        let maskPath = UIBezierPath(roundedRect: view.bounds,
                                    byRoundingCorners: [.bottomLeft, .bottomRight],
                                    cornerRadii: CGSize(width: radius, height: radius))
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = maskPath.cgPath
        view.layer.mask = shapeLayer
    }

    
}


extension UIImageView {
    func applyBottomCornerRadius(to view: UIImageView, radius: CGFloat) {
        let maskPath = UIBezierPath(roundedRect: view.bounds,
                                    byRoundingCorners: [.bottomLeft, .bottomRight],
                                    cornerRadii: CGSize(width: radius, height: radius))
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = maskPath.cgPath
        view.layer.mask = shapeLayer
    }
}

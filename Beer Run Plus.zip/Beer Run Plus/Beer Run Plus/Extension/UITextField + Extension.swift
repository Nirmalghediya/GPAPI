//
//  UITextField + Extension.swift
//  Beer Run Plus
//
//  Created by Jaydeep Patel on 01/02/25.
//

import UIKit


extension UITextField {
    func applylightBorder(textfield:UITextField,placeholder:String){
       
        textfield.placeholder = placeholder
        let attributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor.white
        ]

        textfield.attributedPlaceholder = NSAttributedString(string: textfield.placeholder ?? "", attributes: attributes)
    }
}

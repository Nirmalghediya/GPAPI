

import UIKit

class DrumVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btn_Tapped(_ sender: UIButton) {
        
        if sender.tag == 101 {
            AudioPlayer.shared.Playsound(Resource: "bd7575", Type: "wav")
        }
        else if sender.tag == 102 {
            AudioPlayer.shared.Playsound(Resource: "ch", Type: "wav")
        }
        else if sender.tag == 103 {
            AudioPlayer.shared.Playsound(Resource: "cp", Type: "wav")
        }
        else if sender.tag == 104 {
            AudioPlayer.shared.Playsound(Resource: "ht75", Type: "wav")
        }
        else if sender.tag == 105 {
            AudioPlayer.shared.Playsound(Resource: "sd7575", Type: "wav")
        }
        else if sender.tag == 106 {
            AudioPlayer.shared.Playsound(Resource: "mt75", Type: "wav")
        }
        else if sender.tag == 107 {
            AudioPlayer.shared.Playsound(Resource: "oh75", Type: "wav")
        }
        else if sender.tag == 108 {
            AudioPlayer.shared.Playsound(Resource: "rs", Type: "wav")
        }
        else if sender.tag == 109 {
            AudioPlayer.shared.Playsound(Resource: "sd7575", Type: "wav")
        }
        
    }
    
    

}

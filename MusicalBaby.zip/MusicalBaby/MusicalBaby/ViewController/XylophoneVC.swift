

import UIKit

class XylophoneVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    
    @IBAction func KeyPressed(_ sender: UIButton) {
        
        if sender.tag == 101 {
            AudioPlayer.shared.Playsound(Resource: "A", Type: "wav")
        }
        else if sender.tag == 102 {
            AudioPlayer.shared.Playsound(Resource: "B", Type: "wav")
        }
        else if sender.tag == 103 {
            AudioPlayer.shared.Playsound(Resource: "C", Type: "wav")
        }
        else if sender.tag == 104 {
            AudioPlayer.shared.Playsound(Resource: "D", Type: "wav")
        }
        else if sender.tag == 105 {
            AudioPlayer.shared.Playsound(Resource: "E", Type: "wav")
        }
        else if sender.tag == 106 {
            AudioPlayer.shared.Playsound(Resource: "F", Type: "wav")
        }
        else if sender.tag == 107 {
            AudioPlayer.shared.Playsound(Resource: "G", Type: "wav")
        }
        
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}

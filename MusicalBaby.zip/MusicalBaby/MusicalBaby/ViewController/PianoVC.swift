

import UIKit
import AVFoundation

class PianoVC: UIViewController {
    
    var audioPlayer = AVAudioPlayer()

    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func KeyPressed(_ sender: UIButton) {
        
        print(sender.tag)
        playSound(with: sender.tag)
        
    }
    
    
    func playSound(with noteName : Int){
        if let soundURL = Bundle.main.url(forResource: "note\(noteName)", withExtension: ".wav"){
            do{
                audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
                try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback, mode: AVAudioSession.Mode.default)
            }
            catch{
                print(error)
            }
            audioPlayer.play()
        }
        
    }
    
    
}


import UIKit

class HomeVC: UIViewController {

    @IBOutlet weak var btn_unmute: UIButton!
    @IBOutlet weak var btn_mute: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        btn_mute.isHidden = true
        
        if btn_mute.isHidden {
            AudioPlayer.shared.Playsound(Resource: "Main", Type: "mp3")
            audioPlayer?.play()
        }else {
            audioPlayer?.stop()
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if btn_mute.isHidden {
            AudioPlayer.shared.Playsound(Resource: "Main", Type: "mp3")
            audioPlayer?.play()
        }else {
            audioPlayer?.stop()
        }
    }
    
    @IBAction func btn_piano(_ sender: Any) {
        audioPlayer?.stop()
        let vc = storyboard?.instantiateViewController(withIdentifier: "PianoVC") as! PianoVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btn_xylophone(_ sender: Any) {
        audioPlayer?.stop()
        let vc = storyboard?.instantiateViewController(withIdentifier: "XylophoneVC") as! XylophoneVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btn_drum(_ sender: Any) {
        audioPlayer?.stop()
        let vc = storyboard?.instantiateViewController(withIdentifier: "DrumVC") as! DrumVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btn_unmute(_ sender: Any) {
        audioPlayer?.pause()
        btn_mute.isHidden = false
        btn_unmute.isHidden = true
    }
    
    @IBAction func btn_mute(_ sender: Any) {
        AudioPlayer.shared.Playsound(Resource: "Main", Type: "mp3")
        audioPlayer?.play()
        btn_mute.isHidden = true
        btn_unmute.isHidden = false
    }
    
    
}

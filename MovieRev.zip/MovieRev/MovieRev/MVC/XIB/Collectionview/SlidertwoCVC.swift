//
//  SlidertwoCVC.swift
//  MovieRev
//
//  Created by Nirmal on 09/05/24.
//

import UIKit

class SlidertwoCVC: UICollectionViewCell {
    @IBOutlet weak var SImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

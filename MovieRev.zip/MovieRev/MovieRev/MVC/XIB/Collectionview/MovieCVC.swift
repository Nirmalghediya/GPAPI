//
//  MovieCVC.swift
//  MovieRev
//
//  Created by Nirmal on 09/05/24.
//

import UIKit

class MovieCVC: UICollectionViewCell {
    @IBOutlet weak var lbl_moview: UILabel!
    
    @IBOutlet weak var img_movie: UIImageView!
    
    @IBOutlet weak var BG_View: UIView!
    
    @IBOutlet weak var bottom_View: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

//
//  HomeVC.swift
//  MovieRev
//
//  Created by Nirmal on 08/05/24.
//

import UIKit
@available(iOS 13.0, *)
class HomeVC: UIViewController {

    //MARK: - CollectionView
    
    @IBOutlet weak var SliderOne: UICollectionView!
    
    @IBOutlet weak var OldCollectionView: UICollectionView!
    
    @IBOutlet weak var SliderTwo: UICollectionView!
    
    @IBOutlet weak var MidCollectionView: UICollectionView!
    
    @IBOutlet weak var NewCollectionView: UICollectionView!
    
    @IBOutlet weak var PageOne: UIPageControl!
    
    @IBOutlet weak var PageTwo: UIPageControl!
    
    var Timers = Timer()
    var Counters = 0
    var Timers1 = Timer()
    var Counters1 = 0
    let Slide1 = ["1","2","3","4"]
    let Slide2 = ["5","6","7","8"]
    var movies : [MovieElement] = []
    var movies1 : [MovieElement] = []
    var movies2 : [MovieElement] = []
    var getMovieOf : (()->())?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationController?.navigationBar.isHidden = true
        
        SliderOne.delegate = self
        SliderOne.dataSource = self
        SliderOne.register(UINib(nibName: "SlideroneCVC", bundle: nil), forCellWithReuseIdentifier: "SlideroneCVC")
        
        SliderTwo.delegate = self
        SliderTwo.dataSource = self
        SliderTwo.register(UINib(nibName: "SlidertwoCVC", bundle: nil), forCellWithReuseIdentifier: "SlidertwoCVC")
        
        OldCollectionView.dataSource = self
        OldCollectionView.dataSource = self
        OldCollectionView.register(UINib(nibName: "MovieCVC", bundle: nil), forCellWithReuseIdentifier: "MovieCVC")
        
        MidCollectionView.dataSource = self
        MidCollectionView.dataSource = self
        MidCollectionView.register(UINib(nibName: "MovieCVC", bundle: nil), forCellWithReuseIdentifier: "MovieCVC")
        
        NewCollectionView.dataSource = self
        NewCollectionView.dataSource = self
        NewCollectionView.register(UINib(nibName: "MovieCVC", bundle: nil), forCellWithReuseIdentifier: "MovieCVC")
        
        //PageView
        PageOne.numberOfPages = Slide1.count
        PageOne.currentPage = 0
        DispatchQueue.main.async {
              self.Timers = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.changeImage), userInfo: nil, repeats: true)
           }
        
        PageTwo.numberOfPages = Slide2.count
        PageTwo.currentPage = 0
        DispatchQueue.main.async {
              self.Timers1 = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.changeImage2), userInfo: nil, repeats: true)
           }
        
      OldMovie()
        MidMovie()
       NewMovie()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tabBarController?.tabBar.isHidden = false
    }
    
    
    
    //MARK: - SlideImage
    @objc func changeImage() {
        if Counters < Slide1.count {
             let index = IndexPath.init(item: Counters, section: 0)
             self.SliderOne.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
            PageOne.currentPage = Counters
            Counters += 1
        } else {
            Counters = 0
             let index = IndexPath.init(item: Counters, section: 0)
             self.SliderOne.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
            PageOne.currentPage = Counters
            Counters = 1
          }
      }
    
    @objc func changeImage2() {
        if Counters1 < Slide2.count {
             let index = IndexPath.init(item: Counters1, section: 0)
             self.SliderTwo.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
            PageTwo.currentPage = Counters1
            Counters1 += 1
        } else {
            Counters1 = 0
             let index = IndexPath.init(item: Counters1, section: 0)
             self.SliderTwo.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
            PageTwo.currentPage = Counters1
            Counters1 = 1
          }
      }
    

    @IBAction func btn_one(_ sender: Any)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ViewAllVC") as! ViewAllVC
        vc.resource = "movies-2000s"
        vc.heading = "2000's Movies"
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btn_two(_ sender: Any)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ViewAllVC") as! ViewAllVC
        vc.resource = "movies-2010s"
        vc.heading = "2010's Movies"
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btn_three(_ sender: Any) 
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ViewAllVC") as! ViewAllVC
        vc.resource = "movies-2020s"
        vc.heading = "2020's Movies"
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func OldMovie()
    {
        if let path = Bundle.main.path(forResource: "movies-2000s", ofType: "json"){
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path),options: .mappedIfSafe)
                let decoder = JSONDecoder()
                self.movies = try decoder.decode([MovieElement].self, from: data)
            }
            catch
            {
                print("Error parsing JSON: \(error)")
            }
        }
        OldCollectionView.reloadData()
    }

    func MidMovie()
    {
        if let path = Bundle.main.path(forResource: "movies-2010s", ofType: "json"){
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path),options: .mappedIfSafe)
                let decoder = JSONDecoder()
                self.movies1 = try decoder.decode([MovieElement].self, from: data)
            }
            catch
            {
                print("Error parsing JSON: \(error)")
            }
        }
        MidCollectionView.reloadData()
    }
    
    func NewMovie()
    {
        if let path = Bundle.main.path(forResource: "movies-2020s", ofType: "json"){
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path),options: .mappedIfSafe)
                let decoder = JSONDecoder()
                self.movies2 = try decoder.decode([MovieElement].self, from: data)
            }
            catch
            {
                print("Error parsing JSON: \(error)")
            }
        }
        NewCollectionView.reloadData()
    }

   

}

@available(iOS 13.0, *)
extension HomeVC:UICollectionViewDelegate,UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
      
        if collectionView == SliderOne
        {
            return Slide1.count
        }
        else if collectionView == SliderTwo
        {
            return Slide2.count
        }
        else if collectionView == OldCollectionView
        {
            return 10
        }
            else if collectionView == MidCollectionView
        {
                return 10
            }
        else
        {
            return 10
        }
      
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       if collectionView == SliderOne
        {
           let cell = SliderOne.dequeueReusableCell(withReuseIdentifier: "SlideroneCVC", for: indexPath) as! SlideroneCVC
           cell.SImage.image = UIImage(named: Slide1[indexPath.row])
           cell.SImage.View4x4(img: cell.SImage, Redius: 20)
           return cell
       }
        else if collectionView == OldCollectionView
        {
            let cell = OldCollectionView.dequeueReusableCell(withReuseIdentifier: "MovieCVC", for: indexPath) as! MovieCVC
            cell.BG_View.View4x4(view: cell.BG_View, Redius: 20)
            cell.img_movie.ImageUpperCorner(img: cell.img_movie, Redius: 20)
            cell.bottom_View.ViewBottomCorner(view: cell.bottom_View, Redius: 20)
            let movie = movies[indexPath.item]
            cell.lbl_moview.text = movie.title
            if let thumbnailURLString = movie.thumbnail, let thumbnailURL = URL(string: thumbnailURLString){
                DispatchQueue.global().async {
                                if let imageData = try? Data(contentsOf: thumbnailURL) {
                                    DispatchQueue.main.async {
                                        cell.img_movie.image = UIImage(data: imageData)
                                    }
                                }
                            }
            }
            return cell
        }
        else if collectionView == SliderTwo
        {
            let cell = SliderTwo.dequeueReusableCell(withReuseIdentifier: "SlidertwoCVC", for: indexPath) as! SlidertwoCVC
            cell.SImage.image = UIImage(named: Slide2[indexPath.row])
            cell.SImage.View4x4(img: cell.SImage, Redius: 20)
            return cell
        }
        else if collectionView == MidCollectionView
        {
            let cell = MidCollectionView.dequeueReusableCell(withReuseIdentifier: "MovieCVC", for: indexPath) as! MovieCVC
            cell.BG_View.View4x4(view: cell.BG_View, Redius: 20)
            cell.img_movie.ImageUpperCorner(img: cell.img_movie, Redius: 20)
            cell.bottom_View.ViewBottomCorner(view: cell.bottom_View, Redius: 20)
            let movie = movies1[indexPath.item]
            cell.lbl_moview.text = movie.title
            if let thumbnailURLString = movie.thumbnail, let thumbnailURL = URL(string: thumbnailURLString){
                DispatchQueue.global().async {
                                if let imageData = try? Data(contentsOf: thumbnailURL) {
                                    DispatchQueue.main.async {
                                        cell.img_movie.image = UIImage(data: imageData)
                                    }
                                }
                            }
            }
            return cell
        }
        else
        {
            let cell = NewCollectionView.dequeueReusableCell(withReuseIdentifier: "MovieCVC", for: indexPath) as! MovieCVC
            cell.BG_View.View4x4(view: cell.BG_View, Redius: 20)
            cell.img_movie.ImageUpperCorner(img: cell.img_movie, Redius: 20)
            cell.bottom_View.ViewBottomCorner(view: cell.bottom_View, Redius: 20)
            let movie = movies2[indexPath.item]
            cell.lbl_moview.text = movie.title
            if let thumbnailURLString = movie.thumbnail, let thumbnailURL = URL(string: thumbnailURLString){
                DispatchQueue.global().async {
                                if let imageData = try? Data(contentsOf: thumbnailURL) {
                                    DispatchQueue.main.async {
                                        cell.img_movie.image = UIImage(data: imageData)
                                    }
                                }
                            }
            }
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
                if collectionView == OldCollectionView
                {
                    let vc = storyboard?.instantiateViewController(identifier: "ViewAllVC") as! ViewAllVC
                    vc.resource = "movies-2000s"
                    vc.heading = "2000's Movies"
                    navigationController?.pushViewController(vc, animated: true)
                }
                 if collectionView == MidCollectionView
                {
                     let vc = storyboard?.instantiateViewController(identifier: "ViewAllVC") as! ViewAllVC
                     vc.resource = "movies-2010s"
                     vc.heading = "2010's Movies"
                     navigationController?.pushViewController(vc, animated: true)
                }
                 if collectionView == NewCollectionView
                {
                     let vc = storyboard?.instantiateViewController(identifier: "ViewAllVC") as! ViewAllVC
                     vc.resource = "movies-2020s"
                     vc.heading = "2020's Movies"
                     navigationController?.pushViewController(vc, animated: true)
                }
    }
    
    
}

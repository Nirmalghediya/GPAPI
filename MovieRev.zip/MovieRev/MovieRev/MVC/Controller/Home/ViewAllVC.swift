//
//  ViewAllVC.swift
//  MovieRev
//
//  Created by Nirmal on 08/05/24.
//

import UIKit

class ViewAllVC: UIViewController {

    @IBOutlet weak var MovieCollectionView: UICollectionView!
    
    @IBOutlet weak var lbl_heading: UILabel!
    var movies : [MovieElement]?
    var resource = ""
    var heading = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tabBarController?.tabBar.isHidden = true
        
        lbl_heading.text = heading
        MovieCollectionView.delegate = self
        MovieCollectionView.dataSource = self
        MovieCollectionView.register(UINib(nibName: "MovieCVC", bundle: nil), forCellWithReuseIdentifier: "MovieCVC")
      
        if let path = Bundle.main.path(forResource: resource, ofType: "json"){
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path),options: .mappedIfSafe)
                let decoder = JSONDecoder()
                self.movies = try decoder.decode([MovieElement].self, from: data)
            }
            catch
            {
                print("Error parsing JSON: \(error)")
            }
        }
        
        MovieCollectionView.reloadData()
        
        
        
    }
    
    @IBAction func btn_back(_ sender: Any)
    {
        navigationController?.popViewController(animated: true)
    }
    
   
}

extension ViewAllVC:UICollectionViewDelegate,UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = MovieCollectionView.dequeueReusableCell(withReuseIdentifier: "MovieCVC", for: indexPath) as! MovieCVC
        cell.BG_View.View4x4(view: cell.BG_View, Redius: 20)
        cell.img_movie.ImageUpperCorner(img: cell.img_movie, Redius: 20)
        cell.bottom_View.ViewBottomCorner(view: cell.bottom_View, Redius: 20)
        let movie = movies![indexPath.item]
        cell.lbl_moview.text = movie.title
        if let thumbnailURLString = movie.thumbnail, let thumbnailURL = URL(string: thumbnailURLString){
            DispatchQueue.global().async {
                            if let imageData = try? Data(contentsOf: thumbnailURL) {
                                DispatchQueue.main.async {
                                    cell.img_movie.image = UIImage(data: imageData)
                                }
                            }
                        }
        }
        return cell

    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DetailsVC") as! DetailsVC
        vc.movie = self.movies?[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension ViewAllVC: UICollectionViewDelegateFlowLayout
 {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
    
            let flowayout = collectionViewLayout as? UICollectionViewFlowLayout
            let space: CGFloat = (flowayout?.minimumInteritemSpacing ?? 0.0) + (flowayout?.sectionInset.left ?? 0.0) + (flowayout?.sectionInset.right ?? 0.0)
        let size:CGFloat = (collectionView.frame.size.width - space) / 2.2
        return CGSize(width: size, height: size * 1.5)
       
    }

 }

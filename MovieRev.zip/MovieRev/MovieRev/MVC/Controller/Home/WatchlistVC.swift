//
//  WatchlistVC.swift
//  MovieRev
//
//  Created by Nirmal on 08/05/24.
//

import UIKit


class WatchlistVC: UIViewController {

    
    @IBOutlet weak var WatchlistTableView: UITableView!
    
    var movies : [MovieElement]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.movies = readMovieElements()
        
        navigationController?.navigationBar.isHidden = true
        
        //MovieTVC
        WatchlistTableView.delegate = self
        WatchlistTableView.dataSource = self
        WatchlistTableView.register(UINib(nibName: "MovieTVC", bundle: nil), forCellReuseIdentifier: "MovieTVC")
      
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = false
    }
   

}

extension WatchlistVC:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = WatchlistTableView.dequeueReusableCell(withIdentifier: "MovieTVC", for: indexPath) as! MovieTVC
        cell.img_movie.kf.setImage(with: URL(string: movies?[indexPath.row].thumbnail ?? ""),placeholder: UIImage(named: "placeholder"))
        cell.lbl_extract.text = movies?[indexPath.row].extract
        cell.lbl_title.text = movies?[indexPath.row].title
        cell.lbl_cast.text = movies![indexPath.row].cast?.isEmpty ?? false ? "No Cast Deatils" : movies![indexPath.row].cast?[0]
        cell.selectionStyle = .none
        cell.BG_View.View4x4(view: cell.BG_View, Redius: 20)
        cell.img_movie.View4x4(img: cell.img_movie, Redius: 20)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nextvc = DetailsVC.instantiateViewController() as? DetailsVC
        nextvc?.movie = self.movies?[indexPath.row]
        self.navigationController?.pushViewController(nextvc!, animated: true)
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        self.movies = readMovieElements()
        DispatchQueue.main.async {
            self.WatchlistTableView.reloadData()
        }
        if movies?.count == 0 || movies == nil {
            self.WatchlistTableView.isHidden = true
        }
        else{
            self.WatchlistTableView.isHidden = false
        }
    }
    
}


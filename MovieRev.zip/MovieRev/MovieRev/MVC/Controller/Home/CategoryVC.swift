//
//  CategoryVC.swift
//  MovieRev
//
//  Created by Nirmal on 08/05/24.
//

import UIKit

class CategoryVC: UIViewController {

    
    @IBOutlet weak var GenreTableView: UITableView!
    
    @IBOutlet weak var txt_search: UITextField!
    
    @IBOutlet weak var BG_View: UIView!
    
    var genres : Genres?
    var filterGenres : Genres? = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        BG_View.View4x4(view: BG_View, Redius: 20)
        self.genres = getGenres()
        filterGenres = genres
        
        //CategoryTVC
        GenreTableView.delegate = self
        GenreTableView.dataSource = self
        GenreTableView.register(UINib(nibName: "CategoryTVC", bundle: nil), forCellReuseIdentifier: "CategoryTVC")
        
        
        let placeholder = "Search"
        let placeholdercolor = UIColor.black.withAlphaComponent(CGFloat(10))
        let attributedPlaceholder = NSAttributedString(string: placeholder, attributes: [NSAttributedString.Key.foregroundColor: placeholdercolor])
        txt_search.attributedPlaceholder = attributedPlaceholder
        txt_search.placeholder = placeholder
        txt_search.borderStyle = .none
        txt_search.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = false
    }


}

extension CategoryVC:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterGenres?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = GenreTableView.dequeueReusableCell(withIdentifier: "CategoryTVC", for: indexPath) as! CategoryTVC
        cell.lbl_genre.text = filterGenres?[indexPath.row]
        cell.BG_View.View4x4(view: cell.BG_View, Redius: 20)
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = getMoviesGenres(forGenre: filterGenres![indexPath.row])
        let nextVC = ViewAllVC.instantiateViewController() as? ViewAllVC
        nextVC?.movies = data
        self.navigationController?.pushViewController(nextVC!, animated: true)
    }
    
}

extension CategoryVC : UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let searchText = (textField.text as NSString?)?.replacingCharacters(in: range, with: string) else {
            return true
        }
        
        // Perform search based on the searchText
        print("Search text: \(searchText)")
        
        
        if searchText.isEmpty {
            self.filterGenres = genres
        }
        else {
            self.filterGenres = genres?.filter { $0.lowercased().contains(searchText.lowercased()) }
        }
        
        DispatchQueue.main.async {
            self.GenreTableView.reloadData()
        }
        return true
    }
}

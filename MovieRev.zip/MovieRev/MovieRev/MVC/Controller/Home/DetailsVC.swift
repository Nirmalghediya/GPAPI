//
//  DetailsVC.swift
//  MovieRev
//
//  Created by Nirmal on 09/05/24.
//

import UIKit


class DetailsVC: UIViewController {

    @IBOutlet weak var btn_add: UIButton!
    
    @IBOutlet weak var lbl_heading: UILabel!
    
    @IBOutlet weak var lbl_title: UILabel!
    
    @IBOutlet weak var img_movie: UIImageView!
    
    @IBOutlet weak var img_movie2: UIImageView!
    
    @IBOutlet weak var lbl_year: UILabel!
    
    @IBOutlet weak var lbl_cast: UILabel!
    
    @IBOutlet weak var lbl_genre: UILabel!
    
    @IBOutlet weak var lbl_Extract: UILabel!
    
    //MARK: -Property
    var Images = UIImage()
    var Title = ""
    var year = 0
    var cast = ""
    var genres = ""
    var extract = ""
    var movie : MovieElement?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btn_add.Button4X4(btn: btn_add, Redius: 20)
        img_movie2.View4x4(img: img_movie2, Redius: 20)
        self.img_movie.kf.setImage(with: URL(string: movie?.thumbnail ?? ""),placeholder: UIImage(named: "placeholder"))
        self.img_movie2.kf.setImage(with: URL(string: movie?.thumbnail ?? ""),placeholder: UIImage(named: "placeholder"))
        self.lbl_heading.text = movie?.title ?? "Some Issue"
        self.lbl_title.text = movie?.title ?? "Some Issue"
        self.lbl_year.text = "\(movie?.year! ?? 0)"
        self.lbl_cast.text = movie?.cast?.isEmpty ?? false ? "No Cast Deatils" : movie?.cast?[0]
        self.lbl_Extract.text = movie?.extract ?? "No Description Available"
        
        self.btn_add.setTitle(readMovieElements(byTitle: (movie?.title)!) ?? false ? "Remove From Watchlist" : "Add to Watchlist", for: .normal)
    }
    
    @IBAction func btn_back(_ sender: Any)
    {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btn_add(_ sender: Any) 
    {
        readMovieElements(byTitle: (movie?.title)!) ?? false ? removeMovieElement(withTitle: (movie?.title)!) : addMovieElement(self.movie!)
        self.btn_add.setTitle(readMovieElements(byTitle: (movie?.title)!) ?? false ? "Remove From Watchlist" : "Add to Watchlist", for: .normal)
    }
    

}

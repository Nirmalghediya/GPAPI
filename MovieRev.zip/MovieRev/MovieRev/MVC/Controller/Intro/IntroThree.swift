//
//  IntroThree.swift
//  MovieRev
//
//  Created by Nirmal on 08/05/24.
//

import UIKit

class IntroThree: UIViewController {

    @IBOutlet weak var BG_View: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        BG_View.View4x4(view: BG_View, Redius: 20)
    
    }
    
    @IBAction func btn_Next(_ sender: Any) 
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "MainTabBar") as! MainTabBar
        navigationController?.pushViewController(vc, animated: true)
    }
    
  

}

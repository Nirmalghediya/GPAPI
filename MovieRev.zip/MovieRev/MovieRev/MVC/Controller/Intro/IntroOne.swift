//
//  IntroOne.swift
//  MovieRev
//
//  Created by Nirmal on 08/05/24.
//

import UIKit

class IntroOne: UIViewController {

    @IBOutlet weak var View_BG: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        UserDefaults.standard.set(true, forKey: "Moviefox")
        navigationController?.navigationBar.isHidden = true
        View_BG.View4x4(view: View_BG, Redius: 20)
    }
    
    @IBAction func btn_Next(_ sender: Any)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "IntroTwo") as! IntroTwo
        navigationController?.pushViewController(vc, animated: true)
    }
    

}

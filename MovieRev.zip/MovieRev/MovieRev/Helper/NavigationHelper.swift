//
//  NavigationHelper.swift
//  MovieRev
//
//  Created by Nirmal on 07/05/24.
//

import Foundation
import UIKit
class NavigationHelper {
    static var shared = NavigationHelper()
    
    var navControl : UINavigationController?
}

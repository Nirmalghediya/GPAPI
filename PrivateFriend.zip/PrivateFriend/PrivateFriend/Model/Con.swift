//
//  Con.swift
//  PrivateFriend
//
//  Created by Nirmal on 06/05/24.
//

import Foundation


class Con {
    
    struct UDFs {
        static let password = "password"
    }
    
}

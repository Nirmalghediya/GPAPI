//
//  ItemCVCell.swift
//  PrivateFriend
//
//  Created by Nirmal on 06/05/24.
//

import UIKit

class ItemCVCell: UICollectionViewCell {

    @IBOutlet weak var View_BG: UIView!
    
    @IBOutlet weak var Images: UIImageView!
    
    @IBOutlet weak var label_BG: UIView!
    
    @IBOutlet weak var lbl_Video: UILabel!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

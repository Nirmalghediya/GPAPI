//
//  UIButton + Extension.swift
//  GoogleAuthandSavedatainUD
//
//  Created by Nirmal on 25/05/25.
//

import Foundation
import UIKit

extension UIButton {
    func makeroundButton(){
        layer.cornerRadius = layer.frame.height / 2
    }
}

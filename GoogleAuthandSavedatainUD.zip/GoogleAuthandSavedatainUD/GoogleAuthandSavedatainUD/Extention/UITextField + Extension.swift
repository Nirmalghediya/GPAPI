//
//  UITextField + Extension.swift
//  GoogleAuthandSavedatainUD
//
//  Created by Nirmal on 25/05/25.
//

import Foundation
import UIKit


extension UITextField {
    func applylightBorder(textfield:UITextField,placeholder:String){
       
        textfield.placeholder = placeholder
        let attributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor.white
        ]

        textfield.attributedPlaceholder = NSAttributedString(string: textfield.placeholder ?? "", attributes: attributes)
    }
}

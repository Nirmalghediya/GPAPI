//
//  UIView.swift
//  GoogleAuthandSavedatainUD
//
//  Created by Nirmal on 25/05/25.
//

import Foundation
import UIKit

extension UIView {
    func applylightborder(redius: CGFloat){
        layer.borderWidth = 1.0
        layer.borderColor = UIColor(hex: "#A6CFFE").cgColor
        layer.cornerRadius = redius
    }
    
    func applydarkborder(redius: CGFloat){
        backgroundColor = .clear
        layer.borderWidth = 1.0
        layer.borderColor = UIColor(hex: "#282828").withAlphaComponent(0.6).cgColor
        layer.cornerRadius = redius
    }
    
    func applyotpborder(redius: CGFloat){
        layer.borderWidth = 1.0
        layer.borderColor = UIColor.white.cgColor
        layer.cornerRadius = redius
    }
    
    func applyDarkGrayGradient() {
        layer.cornerRadius = 20
            let gradientLayer = CAGradientLayer()
            gradientLayer.frame = self.bounds
            gradientLayer.colors = [
                UIColor(hex: "#282828").cgColor, // Dark Gray
                UIColor(hex: "#101010").cgColor  // Black
            ]
            gradientLayer.startPoint = CGPoint(x: 0.5, y: 0) // Top Center
            gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)   // Bottom Center

            self.layer.insertSublayer(gradientLayer, at: 0)
        }
    

        func copyView<T: UIView>() -> T? {
            print("Copying View: \(self)")
            guard let archivedData = try? NSKeyedArchiver.archivedData(withRootObject: self, requiringSecureCoding: false),
                  let copiedView = try? NSKeyedUnarchiver.unarchivedObject(ofClass: T.self, from: archivedData) else {
                print("Error: Could not archive/unarchive view")
                return nil
            }
            return copiedView
        }
    
    func makeRound(){
        layer.cornerRadius = layer.frame.height/2
    }
    
}


extension UIColor {
    convenience init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt64()
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: CGFloat(a) / 255)
    }
}

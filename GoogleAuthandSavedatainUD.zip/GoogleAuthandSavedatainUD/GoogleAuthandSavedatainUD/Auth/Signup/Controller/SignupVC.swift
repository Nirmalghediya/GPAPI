//
//  SignupVC.swift
//  GoogleAuthandSavedatainUD
//
//  Created by Nirmal on 25/05/25.
//

import UIKit
import FirebaseAuth

class SignupVC: UIViewController {

    @IBOutlet weak var btnSignup: UIButton!{
        didSet{
            btnSignup.makeroundButton()
        }
    }
    
    @IBOutlet weak var emailView: UIView!{
        didSet{
            emailView.applydarkborder(redius: 10)
        }
    }
    
    @IBOutlet weak var passwordView: UIView!{
        didSet{
            passwordView.applydarkborder(redius: 10)
        }
    }
    
    @IBOutlet weak var facebookView: UIView!{
        didSet{
            facebookView.makeRound()
        }
    }
    
    @IBOutlet weak var googleView: UIView!{
        didSet{
            googleView.backgroundColor = .clear
            googleView.layer.borderWidth = 1.0
            googleView.layer.borderColor = UIColor(hex: "#282828").withAlphaComponent(0.6).cgColor
            googleView.makeRound()
        }
    }
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblLogin: UILabel!
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupSignupLabel()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
       
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func setupSignupLabel() {
        let fullText = "Already have an account? Login"
        let signUpText = "Login"

        let attributedString = NSMutableAttributedString(string: fullText)
        
        // Underline and color the "Sign Up" part
        if let range = fullText.range(of: signUpText) {
            let nsRange = NSRange(range, in: fullText)
            attributedString.addAttribute(.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: nsRange)
            attributedString.addAttribute(.foregroundColor, value: UIColor.systemBlue, range: nsRange)
        }

        lblLogin.attributedText = attributedString
        lblLogin.isUserInteractionEnabled = true

        // Add tap gesture
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didTapSignUpLabel(_:)))
        lblLogin.addGestureRecognizer(tapGesture)
    }

    
    @objc func didTapSignUpLabel(_ gesture: UITapGestureRecognizer) {
        guard let text = lblLogin.attributedText?.string else { return }
        let signUpRange = (text as NSString).range(of: "Login")

        if gesture.didTapAttributedTextInLabel(label: lblLogin, inRange: signUpRange) {
            // Navigate to SignUpVC
            navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func btnSignup(_ sender: Any) {
        guard let email = txtEmail.text else {
            print("E-mail field is empty")
            return
        }
        
        guard let password = txtPassword.text else {
            print("Password field is empty")
            return
        }
        
        if isValidEmail(email) {
            Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
                if let error = error {
                    print("signed failed: \(error.localizedDescription)")
                } else {
                    print("User signed in: \(authResult?.user.email ?? "")")
                    let alert = UIAlertController(title: "Successfully Signed In", message: "Successfully Signed In with Email", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .cancel) { ACTION in
                        self.navigationController?.popViewController(animated: true)
                    }
                    alert.addAction(ok)
                    self.present(alert, animated: true)
                }
            }
        } else {
            let alert = UIAlertController(title: "Alert", message: "Please Enter Valid Email", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .cancel)
            alert.addAction(ok)
            self.present(alert, animated: true)
        }
    }
    
    @IBAction func btnFacebook(_ sender: Any) {
    }
    
    @IBAction func btnGoogle(_ sender: Any) {
    }
    
    
    
    
    
    
    


}

//
//  LoginVC.swift
//  GoogleAuthandSavedatainUD
//
//  Created by Nirmal on 25/05/25.
//

import UIKit
import FirebaseAuth

class LoginVC: UIViewController {

    @IBOutlet weak var EmailView: UIView!{
        didSet{
            EmailView.applydarkborder(redius: 10)
        }
    }
    
    @IBOutlet weak var passwordView: UIView!{
        didSet{
            passwordView.applydarkborder(redius: 10)
        }
    }
    
    
    @IBOutlet weak var btnLogin: UIButton!{
        didSet{
            btnLogin.makeroundButton()
        }
    }
    
    @IBOutlet weak var facebookView: UIView!{
        didSet{
            facebookView.makeRound()
        }
    }
    
    @IBOutlet weak var GoogleView: UIView!{
        didSet{
            GoogleView.backgroundColor = .clear
            GoogleView.layer.borderWidth = 1.0
            GoogleView.layer.borderColor = UIColor(hex: "#282828").withAlphaComponent(0.6).cgColor
            GoogleView.makeRound()
        }
    }
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblSignup: UILabel!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        setupSignupLabel()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)

    }
    
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    func setupSignupLabel() {
        let fullText = "Don’t have an account ? Sign Up"
        let signUpText = "Sign Up"

        let attributedString = NSMutableAttributedString(string: fullText)
        
        // Underline and color the "Sign Up" part
        if let range = fullText.range(of: signUpText) {
            let nsRange = NSRange(range, in: fullText)
            attributedString.addAttribute(.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: nsRange)
            attributedString.addAttribute(.foregroundColor, value: UIColor.systemBlue, range: nsRange)
        }

        lblSignup.attributedText = attributedString
        lblSignup.isUserInteractionEnabled = true

        // Add tap gesture
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didTapSignUpLabel(_:)))
        lblSignup.addGestureRecognizer(tapGesture)
    }

    
    @objc func didTapSignUpLabel(_ gesture: UITapGestureRecognizer) {
        guard let text = lblSignup.attributedText?.string else { return }
        let signUpRange = (text as NSString).range(of: "Sign Up")

        if gesture.didTapAttributedTextInLabel(label: lblSignup, inRange: signUpRange) {
            // Navigate to SignUpVC
            let signupVC = storyboard?.instantiateViewController(withIdentifier: "SignupVC") as! SignupVC
            navigationController?.pushViewController(signupVC, animated: true)
        }
    }

    
    @IBAction func btnLogin(_ sender: Any) {
        guard let email = txtEmail.text else {
            print("E-mail field is empty")
            return
        }
        
        guard let password = txtPassword.text else {
            print("Password field is empty")
            return
        }
        
        if isValidEmail(email) {
            Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
                if let error = error {
                    print("Login failed: \(error.localizedDescription)")
                } else {
                    print("User signed in: \(authResult?.user.email ?? "")")
                }
            }
        } else {
            let alert = UIAlertController(title: "Alert", message: "Please Enter Valid Email", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .cancel)
            alert.addAction(ok)
            self.present(alert, animated: true)
        }
    }
    
    @IBAction func btnGoogle(_ sender: Any) {
    }
    
    @IBAction func btnFacebook(_ sender: Any) {
    }
    
    @IBAction func btnReset(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ResetVC") as! ResetVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

//
//  ResetVC.swift
//  GoogleAuthandSavedatainUD
//
//  Created by Nirmal on 25/05/25.
//

import UIKit
import FirebaseAuth

class ResetVC: UIViewController {

    @IBOutlet weak var emailView: UIView!{
        didSet{
            emailView.applydarkborder(redius: 10)
        }
    }
    
    @IBOutlet weak var btnNext: UIButton!{
        didSet{
            btnNext.makeroundButton()
        }
    }
    
    @IBOutlet weak var btnBack: UIButton!{
        didSet{
            btnBack.makeroundButton()
        }
    }
    
    @IBOutlet weak var txtEmail: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
      
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    @IBAction func btnNext(_ sender: Any) {
        guard let email = txtEmail.text, !email.isEmpty else {
            self.showToast(message: "Please enter your email.")
               
                return
            }
            
            guard isValidEmail(email) else {
                self.showToast(message: "Please enter a valid email address.")
                return
            }

            Auth.auth().sendPasswordReset(withEmail: email) { error in
                if let error = error {
                    self.showToast(message: "\(error.localizedDescription)")
                } else {
                    self.showToast(message: "Password reset email sent.")
                }
            }
    }
    
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    

}

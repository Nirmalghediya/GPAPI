//
//  ImageModel.swift
//  JexgaBackgroundRemover
//
//  Created by Nirmal on 13/06/24.
//

import Foundation

//Save Image Model

struct ImageModel: Codable {
    let data: Data
    let id: String
}

//
//  APIClass.swift
//  JexgaBackgroundRemover
//
//  Created by Nirmal on 13/06/24.
//

import Foundation

class APIManager {
    static let shared = APIManager()

    private init() {}

    func removeBackground(imageData: Data, completion: @escaping (Result<Data, Error>) -> Void) {
        let url = "https://api.remove.bg/v1.0/removebg"
        let headers: HTTPHeaders = [
            "X-Api-Key": "2WhNU9Wrs6MrmmjG2b7DnQHN"
        ]
        let parameters: [String: String] = [
            "size": "auto" // Add any required parameters here
        ]

        AF.upload(multipartFormData: { multipartFormData in
            multipartFormData.append(imageData, withName: "image_file", fileName: "image.png", mimeType: "image/png")
        }, to: url, method: .post, headers: headers).response { response in
            switch response.result {
            case .success(let data):
                if let data = data {
                    completion(.success(data))
                } else {
                    completion(.failure(AFError.responseValidationFailed(reason: .dataFileNil)))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}

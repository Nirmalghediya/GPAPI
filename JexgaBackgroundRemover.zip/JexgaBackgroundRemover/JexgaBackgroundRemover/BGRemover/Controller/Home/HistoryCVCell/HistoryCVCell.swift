//
//  HistoryCVCell.swift
//  JexgaBackgroundRemover
//
//  Created by Nirmal on 13/06/24.
//

import UIKit

class HistoryCVCell: UICollectionViewCell {

    @IBOutlet weak var img: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}



import UIKit

class HomeVC: UIViewController {

    @IBOutlet weak var Edit_View: UIView!
    
    @IBOutlet weak var RBG_View: UIView!
    
    @IBOutlet weak var Sub_EView: UIView!
    
    @IBOutlet weak var Sub_RView: UIView!
    
    @IBOutlet weak var HistoryCollectionView: UICollectionView!
    
    @IBOutlet weak var savedLbl: UILabel!
    
    @IBOutlet weak var viewAllBtn: UIButton!
    
    
    
    
    var drawingList: [ImageModel]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
       //HistoryCVCell
        HistoryCollectionView.delegate = self
        HistoryCollectionView.dataSource = self
        HistoryCollectionView.register(UINib(nibName: "HistoryCVCell", bundle: nil), forCellWithReuseIdentifier: "HistoryCVCell")
        
        let Ec = UITapGestureRecognizer(target: self, action: #selector(editImage))
        Edit_View.addGestureRecognizer(Ec)
        
        let Rc = UITapGestureRecognizer(target: self, action: #selector(RBGImage))
        RBG_View.addGestureRecognizer(Rc)
        
        SetupUI()
    }
    
    @objc func editImage() {
        let vc = storyboard?.instantiateViewController(withIdentifier: "EditImgVC") as! EditImgVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func RBGImage() {
        let vc = storyboard?.instantiateViewController(withIdentifier: "RemoveBGVC") as! RemoveBGVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        tabBarController?.tabBar.isHidden = false
        print("is hidden \(UserDefaults.standard.object(forKey: "savedDrawings") == nil)")
        
        HistoryCollectionView.isHidden = UserDefaults.standard.object(forKey: "savedDrawings") == nil
        savedLbl.isHidden = UserDefaults.standard.object(forKey: "savedDrawings") == nil
        viewAllBtn.isHidden = UserDefaults.standard.object(forKey: "savedDrawings") == nil
        
        if UserDefaults.standard.object(forKey: "savedDrawings") != nil {
            let decoded  = UserDefaults.standard.data(forKey: "savedDrawings")
            do {
                let list = try JSONDecoder().decode([ImageModel].self, from: decoded!)
                drawingList = list
                HistoryCollectionView.reloadData()
            } catch let error {
                let alert = UIAlertController(title: "Error getting drawings", message: "error.localizedDescription", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                print("Error \(error.localizedDescription)")
            }
        }
    }
    
    
    
    
    
    
    @IBAction func btn_View(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "HistoryVC") as! HistoryVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func btn_setting(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SettingVC") as! SettingVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    func SetupUI(){
        Edit_View.View4x4(view: Edit_View, Redius: 20)
        RBG_View.View4x4(view: RBG_View, Redius: 20)
        Sub_EView.ViewBottomCorner(view: Sub_EView, Redius: 20)
        Sub_RView.ViewBottomCorner(view: Sub_RView, Redius: 20)
    }
   

}

extension HomeVC:UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if drawingList?.count != 0 {
            return drawingList?.count ?? 0
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = HistoryCollectionView.dequeueReusableCell(withReuseIdentifier: "HistoryCVCell", for: indexPath) as! HistoryCVCell
            cell.img.image = UIImage(data: drawingList![indexPath.row].data)
            cell.img.View4x4(img: cell.img, Redius: 20)
            return cell
    }
    
    
}

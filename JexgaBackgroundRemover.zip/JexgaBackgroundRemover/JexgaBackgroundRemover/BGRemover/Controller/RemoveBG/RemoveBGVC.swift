//
//  RemoveBGVC.swift
//  JexgaBackgroundRemover
//
//  Created by Nirmal on 14/06/24.
//

import UIKit

class RemoveBGVC: UIViewController {

    
    @IBOutlet weak var RBGimageView: UIImageView!
    
    var drawingList: [ImageModel]?
    var drawingId: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func btn_photo(_ sender: Any) {
        let imagePickerController = UIImagePickerController()
               imagePickerController.delegate = self
               imagePickerController.sourceType = .photoLibrary
               present(imagePickerController, animated: true, completion: nil)
    }
    
    @IBAction func btn_shave(_ sender: Any) {
        let userDefaults = UserDefaults.standard
        if userDefaults.object(forKey: "savedDrawings") != nil {
            let decoded  = userDefaults.data(forKey: "savedDrawings")
            do {
                let list = try JSONDecoder().decode([ImageModel].self, from: decoded!)
                drawingList = list
            } catch let error {
                let alert = UIAlertController(title: "Error saving File Try again", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                print("Error \(error.localizedDescription)")
            }
        } else {
            drawingList = [ImageModel]()
        }
        
        let img = RBGimageView.image!
        guard let data = img.pngData() else {
            // Show alert error saving drawing.
            return
        }
        

        
        if let row = drawingList!.firstIndex(where: {$0.id == drawingId}) {
            drawingList![row] = ImageModel(data: data, id: drawingId ?? "")
        }
        
        if !drawingList!.contains(where: { $0.id == drawingId ?? ""}) {
            drawingList?.append(ImageModel(data: data, id: UUID().uuidString))
        }
        
        do {
            let encodeData = try JSONEncoder().encode(drawingList!)
                UserDefaults.standard.set(encodeData, forKey: "savedDrawings")
            let alert = UIAlertController(title: "Saved", message: "Image Saved", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default,handler: { action in
                if let selectedImage = self.RBGimageView.image {
                    self.saveImageToPhotoLibrary(image: selectedImage)
                    }
            
                self.navigationController?.popViewController(animated: true)
            }))
            self.present(alert, animated: true, completion: nil)
            
        } catch let error {
            let alert = UIAlertController(title: "Error saving File Try again", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            print("Error \(error.localizedDescription)")
        }
    }
    
    @IBAction func btn_share(_ sender: UIButton) {
        // Replace with the name of your image
                guard let image = RBGimageView.image else {
                    print("Image not found!")
                    return
                }

                let activityViewController = UIActivityViewController(activityItems: [image], applicationActivities: nil)

                // For iPads: to prevent crash on iPads
                if let popoverController = activityViewController.popoverPresentationController {
                    popoverController.sourceView = sender
                    popoverController.sourceRect = sender.bounds
                }

                present(activityViewController, animated: true, completion: nil)
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    //MARK: Download Wallpaper
    func saveImageToPhotoLibrary(image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }
    
    

}

extension RemoveBGVC:UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            picker.dismiss(animated: true, completion: nil)
            if let image = info[.originalImage] as? UIImage {
                handleImageSelection(image)
            }
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true, completion: nil)
        }

        func handleImageSelection(_ image: UIImage) {
            guard let imageData = image.pngData() else {
                // Handle the case where image data is nil
                return
            }

            // Call the API to remove background
            APIManager.shared.removeBackground(imageData: imageData) { result in
                switch result {
                case .success(let data):
                    if let image = UIImage(data: data) {
                        DispatchQueue.main.async {
                            // Display the resulting image
                            self.RBGimageView.image = image
                        }
                    }
                case .failure(let error):
                    // Handle the error
                    print("Failed to remove background: \(error)")
                }
            }
        }
}

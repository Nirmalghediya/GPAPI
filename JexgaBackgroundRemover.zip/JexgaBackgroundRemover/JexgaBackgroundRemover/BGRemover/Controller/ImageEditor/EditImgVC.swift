//
//  EditImgVC.swift
//  JexgaBackgroundRemover
//
//  Created by Nirmal on 13/06/24.
//

import UIKit

class EditImgVC: UIViewController {

    
    @IBOutlet weak var editImageView: UIImageView!
    
    @IBOutlet weak var selectPhotoLbl: UILabel!
    
    
    var resultImageView: UIImageView!
    var originalImage: UIImage?
    var resultImageEditModel: ZLEditImageModel?
    var drawingId: String?
    var imageGot: UIImage?
    
    var vc: ZLEditImageViewController!
    
    var drawingList: [ImageModel]?
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ZLImageEditorConfiguration.default()
            .editImageTools([.draw, .clip, .imageSticker, .textSticker, .mosaic, .filter, .adjust])
            .adjustTools([.brightness, .contrast, .saturation])
        if let imagegot = imageGot {
            setImage(img: imagegot)
        }
    }
    
    func setImage(img: UIImage) {
        self.selectPhotoLbl.isHidden = true
        self.originalImage = img
        self.editImageView.image = img
        self.editImageView.backgroundColor = .clear
    }
    
    @IBAction func btn_photo(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.mediaTypes = ["public.image"]
        showDetailViewController(picker, sender: nil)
    }
    
    @IBAction func btn_save(_ sender: Any) {
        let userDefaults = UserDefaults.standard
        if userDefaults.object(forKey: "savedDrawings") != nil {
            let decoded  = userDefaults.data(forKey: "savedDrawings")
            do {
                let list = try JSONDecoder().decode([ImageModel].self, from: decoded!)
                drawingList = list
            } catch let error {
                let alert = UIAlertController(title: "Error saving File Try again", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                print("Error \(error.localizedDescription)")
            }
        } else {
            drawingList = [ImageModel]()
        }
        
        let img = editImageView.image!
        guard let data = img.pngData() else {
            // Show alert error saving drawing.
            return
        }
        

        
        if let row = drawingList!.firstIndex(where: {$0.id == drawingId}) {
            drawingList![row] = ImageModel(data: data, id: drawingId ?? "")
        }
        
        if !drawingList!.contains(where: { $0.id == drawingId ?? ""}) {
            drawingList?.append(ImageModel(data: data, id: UUID().uuidString))
        }
        
        do {
            let encodeData = try JSONEncoder().encode(drawingList!)
                UserDefaults.standard.set(encodeData, forKey: "savedDrawings")
            let alert = UIAlertController(title: "Save", message: "Image Saved", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default,handler: { action in
                if let selectedImage = self.editImageView.image {
                    self.saveImageToPhotoLibrary(image: selectedImage)
                    }
            
                self.navigationController?.popViewController(animated: true)
            }))
            self.present(alert, animated: true, completion: nil)
            
        } catch let error {
            let alert = UIAlertController(title: "Error saving File Try again", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            print("Error \(error.localizedDescription)")
        }
    }
    
    @IBAction func btn_edit(_ sender: Any) {
        guard selectPhotoLbl.isHidden else {
            presentAlert(title: "", message: "Please select image")
            return
        }
        
        guard let originalImage else { return }
        
        self.editImage(originalImage, editModel: resultImageEditModel)
    }
    
    @IBAction func btn_share(_ sender: UIButton) {
        // Replace with the name of your image
                guard let image = editImageView.image else {
                    print("Image not found!")
                    return
                }

                let activityViewController = UIActivityViewController(activityItems: [image], applicationActivities: nil)

                // For iPads: to prevent crash on iPads
                if let popoverController = activityViewController.popoverPresentationController {
                    popoverController.sourceView = sender
                    popoverController.sourceRect = sender.bounds
                }

                present(activityViewController, animated: true, completion: nil)
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func presentAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func editImage(_ image: UIImage, editModel: ZLEditImageModel?) {
        ZLEditImageViewController.showEditImageVC(parentVC: self, image: image, editModel: editModel) { [weak self] resImage, editModel in
//            self?.resultImageView.image = resImage
            self?.editImageView.image = resImage
            self?.resultImageEditModel = editModel
        }
    }
    //MARK: Download Wallpaper
    func saveImageToPhotoLibrary(image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }
   
}

extension EditImgVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        picker.dismiss(animated: true) {
            guard var image = info[.originalImage] as? UIImage else { return }
            let w = min(1500, image.zl.width)
            let h = w * image.zl.height / image.zl.width
            image = image.zl.resize(CGSize(width: w, height: h)) ?? image
            self.resultImageEditModel = nil
            self.setImage(img: image)
            self.editImage(image, editModel: nil)
        }
    }
}
